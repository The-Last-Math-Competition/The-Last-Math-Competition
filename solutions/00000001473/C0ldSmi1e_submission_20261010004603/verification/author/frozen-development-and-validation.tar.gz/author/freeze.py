#!/usr/bin/env python3
"""Freeze or verify the delivered scratch project and author record.
After creation, --verify performs read-only validation of the frozen files.
Root paths can be overridden after copying the two delivery directories.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--proof', type=Path, default=Path('/private/tmp/tlmc1473-proof'))
    parser.add_argument('--author', type=Path, default=Path('/private/tmp/tlmc1473-author'))
    parser.add_argument('--verify', action='store_true')
    args = parser.parse_args()
    roots = {'proof': args.proof.resolve(), 'author': args.author.resolve()}
    manifest_path = roots['author'] / 'FREEZE.json'
    if args.verify:
        manifest = json.loads(manifest_path.read_text())
        for name, entry in manifest['files'].items():
            label, relative = name.split('/', 1)
            p = roots[label] / relative
            assert p.is_file() and not p.is_symlink(), name
            assert p.stat().st_size == entry['bytes'], name
            assert digest(p) == entry['sha256'], name
        print('Verified', len(manifest['files']), 'frozen files.')
        print('FREEZE.json SHA-256:', digest(manifest_path))
        return
    assert not manifest_path.exists(), 'Freeze already exists; do not overwrite it.'
    final = roots['author'] / 'final-validation'
    assert (final / 'SUCCESS.txt').is_file()
    commands = json.loads((final / 'commands.json').read_text())
    assert len(commands) == 25 and all(c['returncode'] == 0 for c in commands)
    for relative, expected in json.loads((final / 'source-hashes.json').read_text()).items():
        assert digest(roots['proof'] / relative) == expected
    pins = {'lean-toolchain': '55e97be96000b5e9e290c9e74482e5e317861499a5540353ce845471bded8cea',
            'lake-manifest.json': '56f7aa9722d120b38ffe868179164054411be9398660939609cb8a0c55e48637'}
    for name, expected in pins.items():
        assert digest(roots['proof'] / name) == expected
    files = {}
    for label, root in roots.items():
        for p in sorted(root.rglob('*')):
            relative = p.relative_to(root)
            if '.lake' in relative.parts or '__pycache__' in relative.parts or p == manifest_path:
                continue
            if p.is_file():
                assert not p.is_symlink(), p
                files[f'{label}/{relative}'] = {'sha256': digest(p), 'bytes': p.stat().st_size}
    manifest = {
        'format': 'sha256-freeze-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'Every delivered source, argument, provenance record, input copy, script, and validation log in the proof and author directories.',
        'excluded': ['The FREEZE.json manifest itself', 'Generated .lake content and cached stock dependencies', 'Generated __pycache__ directories'],
        'roots_at_freeze': {label: str(root) for label, root in roots.items()},
        'source_manifest_sha256': '0f534b95af895ffe575cd78cad6407938bd5f8b4bae83100f6729a623e097c4d',
        'source_conjecture_sha256': 'bdceacf9b92330afb3ee49161d60a121e65ad4724d70bf332b76f7c843ba89d5',
        'final_validation_command_count': len(commands),
        'files': files,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print('Frozen', len(files), 'files.')
    print('FREEZE.json SHA-256:', digest(manifest_path))
    for name in ['proof/Proximity.lean', 'proof/Audit.lean', 'author/ARGUMENT.md', 'author/PROVENANCE.md', 'author/final-validation/22.log']:
        print(name, files[name]['sha256'])


if __name__ == '__main__':
    main()
