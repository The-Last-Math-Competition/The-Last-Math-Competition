#!/usr/bin/env python3
import pathlib,subprocess,sys,json,datetime
root=pathlib.Path('/private/tmp/tlmc1473-author')
logs=root/'logs'; logs.mkdir(exist_ok=True)
idx=len(list(logs.glob('run-*.json')))+1
stem=logs/f'run-{idx:03d}'
cmd=sys.argv[1:]
sources={str(p.relative_to('/private/tmp/tlmc1473-proof')):p.read_text() for p in pathlib.Path('/private/tmp/tlmc1473-proof').rglob('*.lean') if '.lake' not in p.parts}
stem.with_suffix('.sources.json').write_text(json.dumps(sources,indent=2))
r=subprocess.run(cmd,cwd='/private/tmp/tlmc1473-proof',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
record={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':'/private/tmp/tlmc1473-proof','command':cmd,'returncode':r.returncode,'output':r.stdout}
stem.with_suffix('.json').write_text(json.dumps(record,indent=2))
stem.with_suffix('.log').write_text(r.stdout)
print(f'LOG {stem.name} EXIT {r.returncode}\n{r.stdout}')
sys.exit(r.returncode)
