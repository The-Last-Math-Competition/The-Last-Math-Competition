#!/usr/bin/env python3
"""Rebuild and replay this project; use only the supplied stock dependency cache.
Example: python3 validate.py --lean-bin /path/to/lean-4.19.0/bin \
  --mathlib /path/to/stock/mathlib --log-dir /path/to/audit-logs
Without --mathlib, the standard Lake package layout must already be available.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MANIFEST_SHA = '56f7aa9722d120b38ffe868179164054411be9398660939609cb8a0c55e48637'
TOOLCHAIN_SHA = '55e97be96000b5e9e290c9e74482e5e317861499a5540353ce845471bded8cea'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean-bin', type=Path)
    parser.add_argument('--mathlib', type=Path)
    parser.add_argument('--log-dir', type=Path, default=ROOT / 'validation-logs')
    args = parser.parse_args()
    logs = args.log_dir.resolve()
    logs.mkdir(parents=True, exist_ok=False)
    records = []
    env = os.environ.copy()
    if args.lean_bin:
        env['PATH'] = str(args.lean_bin.resolve()) + os.pathsep + env.get('PATH', '')
    lake = str(args.lean_bin.resolve() / 'lake') if args.lean_bin else shutil.which('lake')
    lean = str(args.lean_bin.resolve() / 'lean') if args.lean_bin else shutil.which('lean')
    assert lake and lean

    def run(command, cwd=ROOT):
        result = subprocess.run(command, cwd=cwd, env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        i = len(records) + 1
        record = {'command': list(map(str, command)), 'cwd': str(cwd),
                  'returncode': result.returncode, 'output': result.stdout}
        records.append(record)
        (logs / f'{i:02d}.log').write_text(result.stdout)
        (logs / 'commands.json').write_text(json.dumps(records, indent=2))
        print(f'[{i:02d}] exit={result.returncode}: ' + ' '.join(map(str, command)), flush=True)
        print(result.stdout, end='', flush=True)
        if result.returncode:
            raise RuntimeError(f'Command {i} failed; preserved in {logs}')
        return result.stdout

    assert sha(ROOT / 'lake-manifest.json') == MANIFEST_SHA
    assert sha(ROOT / 'lean-toolchain') == TOOLCHAIN_SHA
    manifest = json.loads((ROOT / 'lake-manifest.json').read_text())
    package_dir = ROOT / '.lake/packages'
    package_dir.mkdir(parents=True, exist_ok=True)
    if args.mathlib:
        stock = args.mathlib.resolve()
        for package in manifest['packages']:
            name = package['name']
            target = stock if name == 'mathlib' else stock / '.lake/packages' / name
            destination = package_dir / name
            if destination.exists() or destination.is_symlink():
                assert destination.resolve() == target.resolve(), (destination, target)
            else:
                destination.symlink_to(target, target_is_directory=True)
    pins = {}
    for package in manifest['packages']:
        checkout = (package_dir / package['name']).resolve()
        actual = run(['git', 'rev-parse', 'HEAD'], checkout).strip()
        assert actual == package['rev'], (package['name'], actual, package['rev'])
        run(['git', 'diff', '--quiet', 'HEAD', '--'], checkout)
        pins[package['name']] = actual
    (logs / 'verified-pins.json').write_text(json.dumps(pins, indent=2))
    assert '4.19.0' in run([lean, '--version'])
    run([lake, '--version'])
    authored = sorted(p for p in ROOT.rglob('*.lean') if '.lake' not in p.parts)
    for p in authored:
        # Prohibit proof escape hatches in delivered Lean sources.
        for token in ('sorry', 'admit', 'native_decide', 'axiom '):
            assert token not in p.read_text(), (p, token)
    (logs / 'source-hashes.json').write_text(json.dumps(
        {str(p.relative_to(ROOT)): sha(p) for p in authored}, indent=2))
    build = ROOT / '.lake/build'
    if build.exists():
        shutil.rmtree(build)
    assert not build.exists()
    (logs / 'fresh-build.txt').write_text('Removed only this project\'s local .lake/build before lake build.\n')
    run([lake, 'build'])
    for p in authored:
        run([lake, 'env', 'lean', '-DwarningAsError=true', str(p.relative_to(ROOT))])
    run([sys.executable, 'exact_audit.py'])
    assert sha(ROOT / 'lake-manifest.json') == MANIFEST_SHA
    assert sha(ROOT / 'lean-toolchain') == TOOLCHAIN_SHA
    (logs / 'SUCCESS.txt').write_text('All pinned dependencies verified; fresh build; every authored Lean source replayed with warnings as errors; exact audit passed.\n')
    print('VALIDATION SUCCESS', flush=True)


if __name__ == '__main__':
    main()
