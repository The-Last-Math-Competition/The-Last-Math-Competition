# Conjecture 00000001473: explicit upper-bound counterexample

`Proximity.lean` defines four actual pure integer linear programs and proves exact, unique real and integer optima, relaxation vertices, full-data Delta=10, infinity distance=50, and strict violations of n*Delta. `Audit.lean` prints the final theorem types, the operative definitions, and axiom dependencies. See the accompanying `ARGUMENT.md` for the full mathematical explanation and `PROVENANCE.md` for provenance and limitations.

The original `lean-toolchain` and `lake-manifest.json` are preserved byte for byte. The toolchain is Lean 4.19.0, with Mathlib revision `c44e0c8ee63ca166450922a373c7409c5d26b00b`.

With the pinned dependencies already available, run:

```
lake build
lake env lean -DwarningAsError=true Proximity.lean
lake env lean -DwarningAsError=true Audit.lean
lake env lean -DwarningAsError=true lakefile.lean
python3 exact_audit.py
```

For a fully logged fresh local rebuild using an existing pristine stock dependency cache:

```
python3 validate.py --lean-bin /path/to/lean-4.19.0/bin \
  --mathlib /path/to/stock/mathlib --log-dir /path/to/new-validation-logs
```

The validation script checks every dependency revision and tracked-source cleanliness, removes only this project's local `.lake/build`, runs the build, replays every authored Lean source with warnings as errors, and executes the exact arithmetic audit. The log directory must be new. The cache argument points at the stock Mathlib checkout whose `.lake/packages` contains the pinned transitive dependencies. No cache code is bundled into the proof and no custom helper library is used.
