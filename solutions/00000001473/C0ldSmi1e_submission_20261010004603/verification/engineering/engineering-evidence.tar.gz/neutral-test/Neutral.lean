import Lean
namespace Neutral
theorem verified : True := True.intro
end Neutral
