import lakefile
import ClosureCheck
#inspect_modules [lakefile, ClosureCheck, Verification.ClosureAudit] "infrastructure-audit.json"
