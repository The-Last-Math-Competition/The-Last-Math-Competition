import VerificationControls.CustomAxiom
import Verification.ClosureAudit
#audit_modules [VerificationControls.CustomAxiom] "control-CustomAxiom.json"
