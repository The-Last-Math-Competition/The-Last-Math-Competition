import Lean
unsafe def hiddenUnsafe : Nat := 0
theorem exported : hiddenUnsafe = 0 := by rfl
