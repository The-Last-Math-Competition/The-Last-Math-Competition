import VerificationControls.NativeDecision
import Verification.ClosureAudit
#audit_kernel_modules [VerificationControls.NativeDecision] "control-NativeDecision.json"
