import Lean
unsafe def hiddenUnsafe : Nat := 0
