import Lean
axiom hidden : False
theorem exported : False := hidden
