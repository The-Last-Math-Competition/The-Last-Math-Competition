import lakefile
import Verification.ClosureAudit
import ClosureCheck

#inspect_modules [lakefile, Verification.ClosureAudit, ClosureCheck] "infrastructure-audit.json"
