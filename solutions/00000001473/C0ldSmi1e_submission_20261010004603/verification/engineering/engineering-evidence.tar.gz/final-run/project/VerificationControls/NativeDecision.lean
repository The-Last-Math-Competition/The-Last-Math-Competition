import Lean
theorem nativeResult : (1 : Nat) = 1 := by native_decide
