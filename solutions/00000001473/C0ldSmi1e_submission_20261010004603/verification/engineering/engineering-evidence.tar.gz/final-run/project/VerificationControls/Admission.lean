import Lean
theorem omitted : True := by sorry
