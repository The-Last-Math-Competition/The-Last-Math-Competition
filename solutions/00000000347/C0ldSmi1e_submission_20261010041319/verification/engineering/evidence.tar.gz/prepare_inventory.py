from pathlib import Path
import hashlib, importlib.util, json, os, shutil
root=Path('/private/tmp/tlmc347-engineering'); source=root/'project'; stage=root/'inventory-stage'; author=Path('/private/tmp/tlmc347-proof'); logs=root/'preparation-logs'
spec=importlib.util.spec_from_file_location('verification',source/'verify.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
author_hashes=json.loads(Path('/private/tmp/tlmc347-author/frozen-source-sha256.json').read_text())
names=['WordCombinatorics.lean','Mechanical.lean','CFRealization.lean','Proof.lean','AxiomAudit.lean','replay.py','lake-manifest.json','lean-toolchain']
for name in names:
 assert m.sha256(author/name)==author_hashes[name],name
 shutil.copy2(author/name,source/name)
for name in names+['lakefile.lean','Verification/ClosureAudit.lean','ClosureCheck.lean']:
 target=stage/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source/name,target)
env=os.environ.copy()
for k in list(env):
 if k.startswith(('GIT_','LEAN_','LAKE_')): env.pop(k)
env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull,GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
env['PATH']='/private/tmp/tlmc310-runtime/lean-4.19.0-darwin_aarch64/bin:'+env.get('PATH','')
m.command(['lake','build'],stage,logs,'inventory-full-lake-build',env)
audit=json.loads((stage/'closure-audit.json').read_text())
m.inspect_audit(stage/'closure-audit.json',['WordCombinatorics','Mechanical','CFRealization','Proof'])
lean_files=['WordCombinatorics.lean','Mechanical.lean','CFRealization.lean','Proof.lean','AxiomAudit.lean','Verification/ClosureAudit.lean','ClosureCheck.lean','lakefile.lean']
freeze=lean_files+['replay.py','verify.py','lake-manifest.json','lean-toolchain']
manifest={'schema_version':1,'problem':'00000000347','proof_modules':['WordCombinatorics','Mechanical','CFRealization','Proof'],
 'inspection_modules':['AxiomAudit','Verification.ClosureAudit','ClosureCheck','lakefile'],
 'lean_files':lean_files,'mutation_control_file':'Proof.lean',
 'frozen_files':{name:m.sha256(source/name) for name in freeze},
 'expected_proof_declarations':{d['name']:d['kind'] for d in audit['declarations']},
 'expected_compiler_runtime_roots':sorted(d['name'] for d in audit['declarations'] if d['unsafe']),
 'auxiliary_commands':[{'file':'replay.py','argv':['{python}','replay.py','--project','{project}','--mathlib','{mathlib}','--lean-bin','{lean_bin}','--work','{work}']}],
 'author_source_sha256':{name:author_hashes[name] for name in names+['lakefile.lean']},
 'integration_changes':{'lakefile.lean':'The default Proof library explicitly lists all mathematical and audit roots. No mathematical source changed.'},
 'runtime_assumptions':'Pinned stock Lean/Mathlib binary caches may be reused; imported objects and executables are hashed, not all stock modules rebuilt.'}
m.write_json(source/'verification-manifest.json',manifest)
print('FROZEN',m.sha256(source/'verification-manifest.json'))
print('inventory',len(audit['declarations']),len(audit['dependency_graph']))
print('unsafe',manifest['expected_compiler_runtime_roots'])
