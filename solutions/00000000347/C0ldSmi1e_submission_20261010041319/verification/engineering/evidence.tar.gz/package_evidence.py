"""Package already-completed engineering evidence, without stock binary caches."""
from pathlib import Path
import hashlib, json, tarfile
root=Path('/private/tmp/tlmc347-engineering')
run=root/'final-run-2'
summary=json.loads((run/'verification.json').read_text())
assert summary['status']=='pass',summary.get('error')
selected=[]
for name in ('project','provenance','preparation-logs','final-run','final-run-2'):
 base=root/name
 for p in base.rglob('*'):
  if not p.is_file() or p.is_symlink(): continue
  relative=p.relative_to(root)
  if any(s in {'__pycache__','.git'} for s in relative.parts): continue
  if '.lake/packages' in str(relative): continue
  if 'stock-overlay' in relative.parts: continue
  selected.append(p)
for name in ('prepare_inventory.py','package_evidence.py','final-run-console.log','final-run-2-console.log','inventory-before-build-stock-source-manifest.json','engineering-review.json'):
 p=root/name
 if p.is_file(): selected.append(p)
# Preserve the inventory bootstrap result, but not its duplicate dependency cache.
selected.append(root/'inventory-stage/closure-audit.json')
selected=sorted(set(selected))
def sha256(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
 return h.hexdigest()
manifest={str(p.relative_to(root)):sha256(p) for p in selected}
index=root/'evidence-sha256.json'
index.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=root/'conjecture347-engineering-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in selected+[index]: tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(manifest)|{'evidence-sha256.json'}
 for name,expected in manifest.items():
  h=hashlib.sha256()
  with tar.extractfile(name) as f:
   for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
  assert h.hexdigest()==expected,name
receipt={'status':'pass','archive':str(archive),'archive_sha256':sha256(archive),
 'evidence_index_sha256':sha256(index),'archive_bytes':archive.stat().st_size,
 'verified_entries':len(manifest),'run_summary_sha256':sha256(run/'verification.json'),
 'proof_manifest_sha256':sha256(root/'project/verification-manifest.json'),
 'contents':'Frozen project, original configuration/provenance, every retained command receipt/output including initial rejected launch, complete proof and infrastructure dependency graphs, negative controls, exact source/object/executable manifests and local rebuilt proof/audit artifacts. External stock binary caches are not bundled; their imported objects are individually hashed.'}
(root/'archive-verification.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,indent=2))
