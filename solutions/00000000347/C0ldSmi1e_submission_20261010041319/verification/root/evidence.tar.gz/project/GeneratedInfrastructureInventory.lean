import AxiomAudit
import Verification.ClosureAudit
import ClosureCheck
import lakefile

#inspect_modules [AxiomAudit, Verification.ClosureAudit, ClosureCheck, lakefile] "infrastructure-audit.json"
