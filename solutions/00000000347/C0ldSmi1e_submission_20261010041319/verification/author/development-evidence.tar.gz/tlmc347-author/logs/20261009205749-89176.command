lake env lean -DwarningAsError=true -o .lake/build/lib/lean/WordCombinatorics.olean WordCombinatorics.lean
