lake env lean -DwarningAsError=true -o WordCombinatorics.olean WordCombinatorics.lean
