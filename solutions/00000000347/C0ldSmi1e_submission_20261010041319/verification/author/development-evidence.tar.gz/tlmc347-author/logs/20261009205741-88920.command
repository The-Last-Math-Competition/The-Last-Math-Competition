lake env lean -DwarningAsError=true Mechanical.lean
