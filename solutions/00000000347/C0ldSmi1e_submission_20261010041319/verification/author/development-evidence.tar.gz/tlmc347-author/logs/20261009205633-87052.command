lake env lean -DwarningAsError=true CFRealization.lean
