lake env lean -DwarningAsError=true Check.lean
