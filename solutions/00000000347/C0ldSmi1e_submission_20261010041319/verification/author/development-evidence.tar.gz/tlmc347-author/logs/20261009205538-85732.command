lake env lean -DwarningAsError=true WordCombinatorics.lean
