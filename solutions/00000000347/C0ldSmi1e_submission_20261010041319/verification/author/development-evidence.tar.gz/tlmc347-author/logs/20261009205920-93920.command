lake env lean -DwarningAsError=true -o .lake/build/lib/lean/Mechanical.olean Mechanical.lean
