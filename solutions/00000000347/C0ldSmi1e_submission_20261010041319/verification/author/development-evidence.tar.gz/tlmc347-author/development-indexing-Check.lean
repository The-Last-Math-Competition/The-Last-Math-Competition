import Proof
#check Transcendental.inv
#check transcendental_inv_iff
#check isAlgebraic_inv
#check isAlgebraic_inv_iff
#check IsAlgebraic.inv
#check CFRealization.completeQuotient
#check CFRealization.partialQuotient
