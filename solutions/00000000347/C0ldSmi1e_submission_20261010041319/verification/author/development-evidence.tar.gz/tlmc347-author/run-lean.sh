#!/bin/zsh
set -o pipefail
cd /private/tmp/tlmc347-proof
export PATH=/private/tmp/tlmc310-runtime/lean-4.19.0-darwin_aarch64/bin:$PATH
stamp=$(date +%Y%m%d%H%M%S)-$$
print -r -- "lake env lean -DwarningAsError=true $*" > /private/tmp/tlmc347-author/logs/$stamp.command
for arg in "$@"; do
  if [[ -f "$arg" ]]; then shasum -a 256 "$arg" >> /private/tmp/tlmc347-author/logs/$stamp.inputs.sha256; fi
done
lake env lean -DwarningAsError=true "$@" 2>&1 | tee /private/tmp/tlmc347-author/logs/$stamp.log
status_code=$?
print -r -- "$status_code" > /private/tmp/tlmc347-author/logs/$stamp.exit
exit "$status_code"
