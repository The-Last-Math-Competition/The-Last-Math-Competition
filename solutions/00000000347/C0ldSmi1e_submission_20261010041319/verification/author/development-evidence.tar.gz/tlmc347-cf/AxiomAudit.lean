import CFRealization

#print axioms CFRealization.realOfWord_bounds
#print axioms CFRealization.partialQuotient_zero
#print axioms CFRealization.partialQuotient_succ
#print axioms CFRealization.completeQuotient_fract_pos
#print axioms CFRealization.realOfWord_injective
