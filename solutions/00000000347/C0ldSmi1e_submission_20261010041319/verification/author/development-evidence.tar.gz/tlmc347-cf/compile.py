import pathlib, os, subprocess, hashlib, time, sys
root=pathlib.Path('/private/tmp/tlmc347-proof')
stock=pathlib.Path('/private/tmp/tlmc-standard-library-419/mathlib')
base=pathlib.Path('/private/tmp/tlmc347-cf')
overlay=base/'stock-overlay'
lean='/private/tmp/tlmc310-runtime/lean-4.19.0-darwin_aarch64/bin/lean'
lake='/private/tmp/tlmc310-runtime/lean-4.19.0-darwin_aarch64/bin/lake'
paths=subprocess.check_output([lake,'env','printenv','LEAN_PATH'],cwd=root,text=True).strip()
paths=':'.join(str((root/p).resolve()) if not p.startswith('/') else p for p in paths.split(':'))
env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+paths

def run(source,out,stockmode=False):
 stamp=str(time.time_ns());log=base/(stamp+'.log')
 cmd=[lean,'-DwarningAsError=true','-R',str(stock if stockmode else root),'-o',str(out),str(source)]
 out.parent.mkdir(parents=True,exist_ok=True)
 (base/(stamp+'.command')).write_text('LEAN_PATH='+env['LEAN_PATH']+'\n'+' '.join(cmd)+'\n')
 (base/(stamp+'.inputs.sha256')).write_text(hashlib.sha256(source.read_bytes()).hexdigest()+'  '+str(source)+'\n')
 p=subprocess.run(cmd,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log.write_text(p.stdout); (base/(stamp+'.exit')).write_text(str(p.returncode)+'\n')
 print(p.stdout,end='');print('Log:',log,'Exit:',p.returncode)
 return p.returncode
if sys.argv[1]=='stock':
 for mod in sys.argv[2:]:
  path=pathlib.Path(*mod.split('.'))
  code=run(stock/(str(path)+'.lean'),overlay/(str(path)+'.olean'),True)
  if code:sys.exit(code)
else:
 source=root/sys.argv[1]
 sys.exit(run(source,root/'.lake/build/lib/lean'/source.with_suffix('.olean').name))
