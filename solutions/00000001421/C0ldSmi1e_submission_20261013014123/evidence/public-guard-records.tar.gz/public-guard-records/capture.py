#!/usr/bin/env python3
"""Bounded candidate metadata only; no solution contents, diffs, or remote writes."""
import ast,base64,csv,datetime,hashlib,io,json,pathlib,re,subprocess,sys,time,urllib.parse
if sys.argv[1:]!=['--run']:raise SystemExit('Prepared only; root review and explicit --run required.')
P=pathlib.Path(__file__).parent;W=P.parents[1];N=W/'neutral-after2899';B=W/'1421/eligibility';F=W/'1030/final-public-guard'
R='The-Last-Math-Competition/The-Last-Math-Competition';C='00000001421';SOURCE='7fefa10d25b135f3e825f57cabc3043c445fd51f1afb38d2a41b026438b6777a';SINCE='2026-10-13T00:36:00Z';CAP=80;SECONDS=180
# Only previously reviewed helper definitions execute; capture bodies never execute.
for path,names in [(F/'capture.py',{'utc','sha','canonical','require','save','load','Evidence','getlist','allcomments'}),(N/'refresh.py',{'connection','updated_pulls','status_collection'})]:
 module=ast.parse(path.read_text());selected=[x for x in module.body if isinstance(x,(ast.FunctionDef,ast.ClassDef)) and x.name in names]
 require_names={x.name for x in selected}
 if require_names!=names:raise RuntimeError('Missing reviewed helper '+str(path))
 exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'))
prepared=load(P/'prepared.json');patterns=prepared['patterns'];leads={};OWN={1013:'90418d901992f65a01e52b2dd46b29d2c6fca267',1014:'3c92bf54e5844603ab6b9011c3289edb1f0a7270',1015:'79a23208dbb988190431c732d9293c29c9761f45'}
comment_fields='id databaseId body createdAt updatedAt url author{login}'
comment_conn='comments(first:20){totalCount nodes{'+comment_fields+'} pageInfo{hasNextPage endCursor}}'
thread_fields='id isResolved isOutdated comments(first:20){totalCount nodes{id databaseId body createdAt updatedAt url path author{login}} pageInfo{hasNextPage endCursor}}'
thread_conn='reviewThreads(first:20){totalCount nodes{'+thread_fields+'} pageInfo{hasNextPage endCursor}}'
common='__typename number title body url state createdAt updatedAt closedAt '+comment_conn
pr_fields=common+' mergedAt mergedBy{login} mergeCommit{oid} headRefOid baseRefOid headRefName headRepository{nameWithOwner} changedFiles reviews(first:100){totalCount nodes{id databaseId body state submittedAt author{login}} pageInfo{hasNextPage endCursor}} '+thread_conn

def parent(x,key):return int(x[key].rsplit('/',1)[1])
def blob(raw):
 b=base64.b64decode(raw['content']);require('exact Git blob',hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==raw['sha']);return b
def scan(kind,n,identifier,fields):
 matches={k:[name for name,pattern in patterns.items() if re.search(pattern,value,re.I)] for k,value in fields.items() if isinstance(value,str)}
 matches={k:v for k,v in matches.items() if v}
 if matches:leads[kind+':'+str(identifier)]={'kind':kind,'parent_number':n,'record_id':identifier,'matches':matches,'metadata_context':fields}
def inline_for_parent(pr):
 """Fresh complete relevant threads/comments; paginate explicit metadata only."""
 n=pr['number'];tc=pr['reviewThreads'];seen=set();threadpages=[{'count':len(tc['nodes']),'totalCount':tc['totalCount'],'pageInfo':dict(tc['pageInfo'])}]
 for tail in range(10):
  if not tc['pageInfo']['hasNextPage']:break
  cursor=tc['pageInfo']['endCursor'];require('new relevant thread cursor',cursor and cursor not in seen);seen.add(cursor)
  q='query{repository(owner:"The-Last-Math-Competition",name:"The-Last-Math-Competition"){pullRequest(number:'+str(n)+'){number headRefOid baseRefOid reviewThreads(first:100,after:'+json.dumps(cursor)+'){totalCount nodes{'+thread_fields+'} pageInfo{hasNextPage endCursor}}}}}'
  raw,_=E.get('parent-'+str(n)+'-threads-tail-'+str(tail)+'.json','graphql',q);z=raw['data']['repository']['pullRequest'];cc=z['reviewThreads'];require('stable relevant thread parent',z['number']==n and all(z[k]==pr[k] for k in ['headRefOid','baseRefOid']) and cc['totalCount']==tc['totalCount']);tc['nodes']+=cc['nodes'];tc['pageInfo']=cc['pageInfo'];threadpages.append({'count':len(cc['nodes']),'totalCount':cc['totalCount'],'pageInfo':dict(cc['pageInfo'])})
 require('complete relevant thread collection',not tc['pageInfo']['hasNextPage'] and len(tc['nodes'])==len({x['id'] for x in tc['nodes']})==tc['totalCount']);out=[];inventory=[]
 for thread in tc['nodes']:
  cc=thread['comments'];seen=set();pages=[{'count':len(cc['nodes']),'totalCount':cc['totalCount'],'pageInfo':dict(cc['pageInfo'])}]
  for tail in range(10):
   if not cc['pageInfo']['hasNextPage']:break
   cursor=cc['pageInfo']['endCursor'];require('new relevant inline cursor',cursor and cursor not in seen);seen.add(cursor)
   q='query{node(id:'+json.dumps(thread['id'])+'){... on PullRequestReviewThread{id comments(first:100,after:'+json.dumps(cursor)+'){totalCount nodes{id databaseId body createdAt updatedAt url path author{login}} pageInfo{hasNextPage endCursor}}}}}'
   raw,_=E.get('parent-'+str(n)+'-thread-'+thread['id']+'-comments-tail-'+str(tail)+'.json','graphql',q);z=raw['data']['node'];nc=z['comments'];require('stable relevant inline count',z['id']==thread['id'] and nc['totalCount']==cc['totalCount']);cc['nodes']+=nc['nodes'];cc['pageInfo']=nc['pageInfo'];pages.append({'count':len(nc['nodes']),'totalCount':nc['totalCount'],'pageInfo':dict(nc['pageInfo'])})
  require('complete relevant inline collection',not cc['pageInfo']['hasNextPage'] and len(cc['nodes'])==len({x['id'] for x in cc['nodes']})==cc['totalCount'])
  for x in cc['nodes']:
   require('inline numeric identifier',x['databaseId'] is not None);out.append({'id':x['databaseId'],'node_id':x['id'],'body':x['body'],'created_at':x['createdAt'],'updated_at':x['updatedAt'],'html_url':x['url'],'path':x['path'],'user':x['author'],'pull_request_url':'https://api.github.com/repos/'+R+'/pulls/'+str(n),'thread_id':thread['id'],'thread_is_resolved':thread['isResolved'],'thread_is_outdated':thread['isOutdated']})
  inventory.append({'id':thread['id'],'comment_count':cc['totalCount'],'comment_ids':[x['databaseId'] for x in cc['nodes']],'pages':pages})
 save(E.path/('parent-'+str(n)+'-inline-inventory.json'),{'number':n,'head_sha':pr['headRefOid'],'base_sha':pr['baseRefOid'],'thread_count':tc['totalCount'],'threads':inventory,'pages':threadpages,'complete':True});return out

E=Evidence(P/'capture');result={'status':'HOLD_INCOMPLETE','candidate':C,'request_cap':CAP,'seconds_cap':SECONDS,'scope':'Current source/rules/metadata/path/history at stable main, retained independently validated neutral catalog with full1009-PR inline/review inventories, overlapping issue/comment and independent updated-pull deltas, exact/topic searches, and complete fresh prior-matched/current-matched/changed/open-parent feedback and filenames, plus all three current own PR checks and statuses before final parent guards. Global inline/review inventories are explicitly inherited from neutral observation interval, not freshly recaptured. Prior root eligibility applies only to earlier local work; this capture makes no new relevance or publication decision. No solution/proof/report/diff content, Git writes, publication, all-fork or full-DAG claim.'}
try:
 require('reviewed capture identity',sha((P/'capture.py').read_bytes())==prepared['script_sha256'])
 for f,h in prepared['dependency_pins'].items():require('pinned dependency '+f,sha((W/f).read_bytes())==h)
 for base in [N,B]:
  for f,h in load(base/'handoff-SHA256SUMS.json').items():require('validated prior manifest '+str(base)+'/'+f,sha((base/f).read_bytes())==h)
 previous=load(B/'result.json');previous_validation=load(B/'validation/validation.json');require('complete independently validated candidate baseline',previous['status']=='CANDIDATE_METADATA_CAPTURE_COMPLETE_ROOT_CLASSIFICATION_PENDING' and previous['candidate']==C and previous_validation['status']=='PASS_CANDIDATE_METADATA_VALIDATION' and not previous_validation['errors']);require('full inherited overlap retained',SINCE==previous['delta_since'] and SINCE<previous['observed_from']);oldparents=set(previous['matched_parent_numbers']);require('prior matched context inventory exact',oldparents=={x['number'] for x in load(B/'capture/matched-parent-contexts.json')})
 prior=load(N/'result.json');snap=load(N/'capture/current-neutral-snapshot.json');require('complete neutral baseline',prior['status']=='NEUTRAL_DELTA_COMPLETE_PENDING_ROOT_REVIEW' and load(N/'validation/validation.json')['status']=='PASS_NEUTRAL_REFRESH_VALIDATION');require('overlap before neutral start',SINCE<prior['observed_from'])
 require('candidate outside neutral exclusions',C not in (N/'excluded-ids.txt').read_text().splitlines());require('exact clean input and corpus manifest',sha((W/'1421/clean-author-input/conjecture.md').read_bytes())==SOURCE==load(W/'clean-conjecture-corpus-manifest.json')['files'][C+'.md'])
 save(P/'preparation.json',{'delta_since':SINCE,'neutral_interval':{k:prior[k] for k in ['observed_from','observed_through','actual_requests']},'request_budget':{'cap':CAP,'seconds':SECONDS,'automatic_retries':0},'dependency_pins':prepared['dependency_pins'],'script_sha256':prepared['script_sha256'],'patterns':patterns,'queries':prepared['queries'],'inheritance':result['scope']})
 main,_=E.get('main-start.json','repos/'+R+'/git/ref/heads/main');mainsha=main['object']['sha'];commit,_=E.get('main-commit.json','repos/'+R+'/git/commits/'+mainsha);tree,_=E.get('root-tree.json','repos/'+R+'/git/trees/'+commit['tree']['sha']);require('root identity complete',commit['sha']==mainsha and tree['sha']==commit['tree']['sha'] and not tree['truncated']);by={x['path']:x for x in tree['tree']};sol,_=E.get('solution-directory-tree.json','repos/'+R+'/git/trees/'+by['solutions']['sha']);require('solution directory complete',sol['sha']==by['solutions']['sha'] and not sol['truncated']);candidate_paths=[x for x in sol['tree'] if x['path']==C]
 source,_=E.get('current-original.json','repos/'+R+'/contents/conjectures/'+C+'.md?ref='+mainsha);sourcebytes=blob(source);require('exact current bilingual original',sha(sourcebytes)==SOURCE and b'**English.**' in sourcebytes and '**中文。**'.encode() in sourcebytes);(P/'ORIGINAL.md').write_bytes(sourcebytes);require('original corpus tree stable',by['conjectures']['sha']==snap['identity']['conjectures_tree_sha']);rules=[]
 for lang,path,heading in [('en','README.md','Rules'),('zh','README.zh-CN.md','比赛规则')]:
  raw,_=E.get('rules-'+lang+'.json','repos/'+R+'/contents/'+path+'?ref='+mainsha);b=blob(raw);m=re.search(r'^## '+re.escape(heading)+r'\s*\n[\s\S]*?(?=^## |\Z)',b.decode(),re.M);require('operative rules found',m is not None);section=(m.group().rstrip('\n')+'\n').encode();old=next(x for x in snap['identity']['rules'] if x['path']==path);require('operative rules exact',raw['sha']==by[path]['sha'] and sha(section)==old['operative_sha256']);(P/('RULES.'+lang+'.md')).write_bytes(section);rules.append({'path':path,'blob_sha':raw['sha'],'whole_sha256':sha(b),'operative_sha256':sha(section)})
 raw,_=E.get('metadata.json','repos/'+R+'/contents/metadata.csv?ref='+mainsha);b=blob(raw);require('metadata root binding',raw['sha']==by['metadata.csv']['sha']);metadata=list(csv.DictReader(io.StringIO(b.decode())));require('metadata exact10000IDs',len(metadata)==10000 and {x['id'] for x in metadata}=={str(i).zfill(11) for i in range(1,10001)});row=next(x for x in metadata if x['id']==C);require('metadata explicitly unsolved',row['proven']==row['disproven']=='false')
 history=getlist('same-path-history.json','repos/'+R+'/commits?sha='+mainsha+'&path=solutions/'+C+'&per_page=100','sha');save(E.path/'current-candidate-binding.json',{'main_sha':mainsha,'root_tree_sha':tree['sha'],'conjectures_tree_sha':by['conjectures']['sha'],'solution_tree_sha':sol['sha'],'original_git_blob_sha':source['sha'],'original_sha256':SOURCE,'candidate_path_entries':candidate_paths,'same_path_history_count':len(history),'metadata_blob_sha':raw['sha'],'metadata_sha256':sha(b),'candidate_metadata':row,'rules':rules})
 delta=E.pages('delta-issues.json','repos/'+R+'/issues?state=all&since='+SINCE+'&sort=updated&direction=asc&per_page=100');comments=E.pages('delta-comments.json','repos/'+R+'/issues/comments?since='+SINCE+'&sort=updated&direction=asc&per_page=100');recent=updated_pulls()
 for x in snap['issues']:scan('neutral_parent',x['number'],x['number'],{'title':x['title'],'body':x.get('body') or ''})
 for x in snap['comments']:scan('neutral_comment',parent(x,'issue_url'),x['id'],{'body':x.get('body') or ''})
 for x in snap['inline']:scan('neutral_inline',parent(x,'pull_request_url'),x['id'],{'body':x.get('body') or ''})
 for pr in snap['reviews']:
  for x in pr['reviews']['nodes']:scan('neutral_review',pr['number'],x['id'],{'body':x.get('body') or ''})
 for pr in load(N/'capture/complete-selected-pr-filename-scopes.json'):
  for path in pr['paths']:scan('neutral_filename',pr['number'],str(pr['number'])+':'+path,{'path':path})
 for x in delta:scan('delta_parent',x['number'],x['number'],{'title':x['title'],'body':x.get('body') or ''})
 for x in recent:scan('updated_pull',x['number'],x['number'],{'title':x['title'],'body':x.get('body') or ''})
 for x in comments:scan('delta_comment',parent(x,'issue_url'),x['id'],{'body':x.get('body') or ''})
 searches=[]
 for index,term in enumerate(prepared['queries']):
  query='repo:'+R+' '+term;raw,_=E.get('search-'+str(index)+'.json','search/issues?q='+urllib.parse.quote(query,safe='')+'&per_page=100');require('bounded complete search',raw['incomplete_results'] is False and raw['total_count']==len(raw['items'])<=100 and len(raw['items'])==len({x['id'] for x in raw['items']}));searches.append({'query':query,'count':len(raw['items'])})
  for x in raw['items']:leads['search:'+str(index)+':'+str(x['number'])]={'kind':'search','parent_number':x['number'],'record_id':str(index)+':'+str(x['number']),'matches':{'query':[query]},'metadata_context':{'title':x['title'],'body':x.get('body') or ''}}
 openparents={x['number'] for x in snap['prs'] if x['state']=='OPEN'};nums=sorted(openparents|{x['number'] for x in delta}|{x['number'] for x in recent}|{parent(x,'issue_url') for x in comments}|{x['parent_number'] for x in leads.values()}|set(OWN)|oldparents);require('bounded relevant parent count',len(nums)<=40)
 save(E.path/'parent-selection.json',{'numbers':nums,'neutral_open_prs':sorted(openparents),'metadata_match_parents':sorted({x['parent_number'] for x in leads.values()}),'own_prs':OWN,'prior_matched_parent_numbers':sorted(oldparents),'rule':'All prior matched contexts, baseline open PRs, new/changed parents, feedback parents, current exact/topic matches, and all three current own PRs.'})
 q='query{repository(owner:"The-Last-Math-Competition",name:"The-Last-Math-Competition"){'+''.join('p'+str(n)+':issueOrPullRequest(number:'+str(n)+'){... on Issue{'+common+'} ... on PullRequest{'+pr_fields+'}}' for n in nums)+'}}';raw,_=E.get('current-parent-metadata.json','graphql',q);parents=[];freshinline=[]
 for z in raw['data']['repository'].values():
  require('parent exists',z is not None);n=z['number'];z['comments']=allcomments(z)
  if z['__typename']=='PullRequest':
   z['reviews']=connection(n,z['headRefOid'],z['baseRefOid'],'reviews',z['reviews'],'id databaseId body state submittedAt author{login}');require('unique reviews',len(z['reviews']['nodes'])==len({x['id'] for x in z['reviews']['nodes']})==z['reviews']['totalCount']);freshinline+=inline_for_parent(z)
  scan('current_parent',n,n,{'title':z['title'],'body':z.get('body') or ''})
  for x in z['comments']['nodes']:scan('current_comment',n,x['id'],{'body':x.get('body') or ''})
  for x in z.get('reviews',{}).get('nodes',[]):scan('current_review',n,x['id'],{'body':x.get('body') or ''})
  parents.append(z)
 for x in freshinline:scan('current_inline',parent(x,'pull_request_url'),x['id'],{'body':x.get('body') or ''})
 catalog={x['number']:x for x in snap['issues']};catalog.update({x['number']:x for x in delta});prnums={n for n,x in catalog.items() if 'pull_request' in x};q='query{repository(owner:"The-Last-Math-Competition",name:"The-Last-Math-Competition"){issues{totalCount} pullRequests{totalCount}}}';counts,_=E.get('current-parent-universe-counts.json','graphql',q);counts=counts['data']['repository'];require('current parent catalog totals',counts['pullRequests']['totalCount']==len(prnums) and counts['issues']['totalCount']==len(catalog)-len(prnums));require('refreshed parents belong catalog',all(z['number'] in catalog and (z['__typename']=='PullRequest')==(z['number'] in prnums) for z in parents))
 knownfiles={};needed=[z['number'] for z in parents if z['__typename']=='PullRequest']
 if needed:
  q='query{repository(owner:"The-Last-Math-Competition",name:"The-Last-Math-Competition"){'+''.join('p'+str(n)+':pullRequest(number:'+str(n)+'){number headRefOid baseRefOid changedFiles files(first:100){totalCount nodes{path} pageInfo{hasNextPage endCursor}}}' for n in needed)+'}}';raw,_=E.get('current-parent-filenames.json','graphql',q)
  for z in raw['data']['repository'].values():
   n=z['number'];pr=next(x for x in parents if x['number']==n);require('filename stable head/base',all(z[k]==pr[k] for k in ['headRefOid','baseRefOid','changedFiles']));cc=connection(n,z['headRefOid'],z['baseRefOid'],'files',z['files'],'path');paths=[x['path'] for x in cc['nodes']];require('complete unique filenames',len(paths)==len(set(paths))==cc['totalCount']==z['changedFiles']);knownfiles[n]={'number':n,'head_sha':z['headRefOid'],'base_sha':z['baseRefOid'],'paths':paths}
   for path in paths:scan('current_filename',n,str(n)+':'+path,{'path':path})
 allinline=[x for x in snap['inline'] if parent(x,'pull_request_url') not in needed]+freshinline;matched=sorted({x['parent_number'] for x in leads.values()}|oldparents);missing=sorted(set(matched)-set(nums));contexts=[{'number':z['number'],'parent_metadata':z,'inline_comments':[x for x in freshinline if parent(x,'pull_request_url')==z['number']],'filename_projection':knownfiles.get(z['number'])} for z in parents if z['number'] in matched]
 save(E.path/'complete-current-parent-metadata.json',parents);save(E.path/'matched-parent-contexts.json',contexts);save(E.path/'metadata-matches.json',list(leads.values()));save(E.path/'fresh-relevant-inline-metadata.json',freshinline);save(E.path/'retained-and-fresh-inline-metadata.json',allinline);save(E.path/'matched-context-completeness.json',{'matched_parent_numbers':matched,'captured_parent_numbers':[x['number'] for x in contexts],'missing_parent_numbers':missing,'complete':not missing});save(E.path/'filename-provenance.json',{'fetched_numbers':needed,'records':[knownfiles[n] for n in needed]})
 save(E.path/'inherited-inventories.json',{'neutral_path':str(N),'neutral_observed_from':prior['observed_from'],'neutral_observed_through':prior['observed_through'],'neutral_inventory_pr_count':prior['catalog_counts']['prs'],'neutral_inline_sha256':sha((N/'capture/complete-inline-inventory.json').read_bytes()),'neutral_review_sha256':sha((N/'capture/complete-review-inventory.json').read_bytes()),'fresh_parent_numbers':nums,'fresh_pr_numbers':needed,'current_catalog_pr_count':len(prnums),'global_inventories_freshly_recaptured':False,'scope':'Complete public universes inherited from independently validated neutral capture; all matched/changed/open-parent collections are freshly complete. No claim of global atomic absence after neutral interval.'})
 own=next(z for z in parents if z['number']==1015);require('latest own head exact',own['headRefOid']=='79a23208dbb988190431c732d9293c29c9761f45');save(E.path/'latest-own-pr-disposition.json',{k:own[k] for k in ['number','state','updatedAt','mergedAt','mergedBy','mergeCommit','headRefOid','baseRefOid']})
 own_feedback=[]
 for n,published_head in OWN.items():
  z=next(x for x in parents if x['number']==n);require('own published head exact '+str(n),z['headRefOid']==published_head)
  checks,checkpages=status_collection(n,published_head,'checks','check-runs','check_runs');statuses,statuspages=status_collection(n,published_head,'status','status','statuses')
  f={k:z[k] for k in ['number','title','state','updatedAt','closedAt','mergedAt','mergedBy','mergeCommit','headRefOid','baseRefOid']};f.update(comments=z['comments']['nodes'],reviews=z['reviews']['nodes'],inline_comments=[x for x in freshinline if parent(x,'pull_request_url')==n],check_runs=checks,statuses=statuses,complete_check_pages=checkpages,complete_status_pages=statuspages);save(E.path/('own-pr'+str(n)+'-feedback.json'),f)
  own_feedback.append({k:f[k] for k in ['number','state','updatedAt','mergedAt','mergedBy','mergeCommit','headRefOid','baseRefOid']}|{'comments':len(f['comments']),'reviews':len(f['reviews']),'inline':len(f['inline_comments']),'checks':len(checks),'statuses':len(statuses)})
 q='query{repository(owner:"The-Last-Math-Competition",name:"The-Last-Math-Competition"){'+''.join('p'+str(n)+':issueOrPullRequest(number:'+str(n)+'){... on Issue{number state updatedAt comments{totalCount}} ... on PullRequest{number headRefOid baseRefOid state updatedAt changedFiles mergedAt mergeCommit{oid} comments{totalCount} reviews{totalCount} reviewThreads{totalCount}}}' for n in nums)+'}}';raw,_=E.get('final-parent-guard.json','graphql',q)
 for z in raw['data']['repository'].values():
  old=next(x for x in parents if x['number']==z['number']);require('final complete parent guard',all(z[k]==old[k] for k in z if k not in ['comments','reviews','reviewThreads']) and all(z[k]['totalCount']==old[k]['totalCount'] for k in ['comments','reviews','reviewThreads'] if k in z))
 end,_=E.get('main-final.json','repos/'+R+'/git/ref/heads/main');require('stable main',end['object']['sha']==mainsha);require('complete matched contexts',not missing);save(E.path/'search-summary.json',searches)
 result.update(status='CANDIDATE_METADATA_CAPTURE_COMPLETE_ROOT_CLASSIFICATION_PENDING',main_sha=mainsha,conjectures_tree_sha=by['conjectures']['sha'],original_sha256=SOURCE,operative_rules_unchanged=True,metadata_unsolved=True,solution_path_absent=not candidate_paths,same_path_history_count=len(history),delta_since=SINCE,delta_counts={'issues':len(delta),'comments':len(comments),'independently_updated_prs':len(recent)},exact_search_counts=[x['count'] for x in searches[:3]],topic_search_counts=[x['count'] for x in searches[3:]],matched_parent_numbers=matched,fresh_parent_numbers=nums,current_catalog_pr_count=len(prnums),inherited_inventory_pr_count=prior['catalog_counts']['prs'],global_inventories_freshly_recaptured=False,fresh_relevant_inline_count=len(freshinline),prior_matched_parent_numbers=sorted(oldparents),own_prs=own_feedback,eligibility_granted=False)
except Exception as ex:result['error']=repr(ex)
finally:
 save(E.path/'errors.json',E.errors);save(E.path/'retry-resolutions.json',E.resolutions);save(E.path/'pagination-index.json',E.pages_log);result.update(actual_requests=E.n,elapsed_seconds=time.monotonic()-E.start,observed_from=min((x['started_at'] for x in E.records),default=None),observed_through=max((x['completed_at'] for x in E.records),default=None));save(P/'result.json',result);save(P/'SHA256SUMS.json',{str(x.relative_to(P)):sha(x.read_bytes()) for x in sorted(P.rglob('*')) if x.is_file() and x!=P/'SHA256SUMS.json'});print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
