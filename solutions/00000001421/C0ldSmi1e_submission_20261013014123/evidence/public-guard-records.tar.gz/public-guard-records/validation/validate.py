#!/usr/bin/env python3
"""Independent offline metadata validation. No network, authorship or eligibility decision.
Original bytes are decoded only for Git/SHA hashes; no original text is rendered.
"""
import ast,base64,copy,csv,datetime,hashlib,io,json,pathlib,re,urllib.parse
V=pathlib.Path(__file__).parent;P=V.parent;W=P.parents[1];C=P/'capture';N=W/'neutral-after2899';B=W/'1421/eligibility';CID='00000001421';R='The-Last-Math-Competition/The-Last-Math-Competition';checks=[]
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def check(label,ok):
 checks.append({'check':label,'pass':bool(ok)})
 if not ok:raise AssertionError(label)
def save(name,x):(V/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def manifest(base,name):
 rows=load(base/name)
 for path,h in rows.items():check('manifest '+str(base.relative_to(W))+'/'+path,sha((base/path).read_bytes())==h)
 return len(rows)
def parent(x,k):return int(x[k].rsplit('/',1)[1])
def blob(name):
 z=load(C/name);b=base64.b64decode(z['content']);check('Git blob '+name,hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==z['sha']);return z,b
r=load(P/'result.json');prep=load(P/'prepared.json');runprep=load(P/'preparation.json');prior=load(N/'result.json');snap=load(N/'capture/current-neutral-snapshot.json');neutral_validation=load(N/'validation/validation.json')
initial_manifests={name:sha((P/name).read_bytes()) for name in ['SHA256SUMS.json']}
check('approved capture script',sha((P/'capture.py').read_bytes())==prep['script_sha256']==runprep['script_sha256']=='9d392ee2623531a91eff21a682f8417faba9b6d9b6aca959aa38b5e8a89a8c7a')
check('capture status',r['status']=='CANDIDATE_METADATA_CAPTURE_COMPLETE_ROOT_CLASSIFICATION_PENDING' and 'error' not in r and r['candidate']==CID and r['eligibility_granted'] is False)
capture_members=manifest(P,'SHA256SUMS.json');neutral_members=manifest(N,'handoff-SHA256SUMS.json');neutral_validation_members=manifest(N/'validation','SHA256SUMS.json')
for name,h in prep['dependency_pins'].items():check('dependency '+name,sha((W/name).read_bytes())==h)
check('run preparation exact pins',prep['dependency_pins']==runprep['dependency_pins'] and prep['patterns']==runprep['patterns'] and prep['queries']==runprep['queries'] and prep['since']==runprep['delta_since'])
check('validated neutral inheritance',neutral_validation['status']=='PASS_NEUTRAL_REFRESH_VALIDATION' and neutral_validation['checks']==10078 and prior['status']=='NEUTRAL_DELTA_COMPLETE_PENDING_ROOT_REVIEW' and neutral_validation['candidate_eligibility_granted'] is False)
check('overlap predates neutral start',prep['since']<prior['observed_from'] and runprep['neutral_interval']=={k:prior[k] for k in ['observed_from','observed_through','actual_requests']})
# Imported helper definitions are parsed only, never executed during validation.
module=ast.parse((P/'capture.py').read_text());check('capture script explicit zero-retry budget',prep['automatic_retries']==0 and prep['request_cap']==80 and prep['seconds_cap']==180)
for src,names in prep['helper_sources'].items():
 tree=ast.parse((W/src).read_text());check('helper definitions present '+src,set(names)<={x.name for x in tree.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))})
root_review=load(P/'root-preflight.json')
check('root approved exact final guard',root_review['status']=='PASS_ROOT_FULL_COLLECTOR_REVIEW_EXECUTION_AUTHORIZED' and root_review['script_sha256']==prep['script_sha256'] and root_review['entire_collector_lines_read']==117 and root_review['dependency_pins_rehashed']==len(prep['dependency_pins'])==36 and root_review['helper_definitions_rehashed']==12 and root_review['prepared_sha256']==sha((P/'prepared.json').read_bytes())=='a63a53f8f3875d2e1fcbed637a57384043d6b1efb9ced4e79782c8ef26f5991a')
prior_candidate_members=manifest(B,'handoff-SHA256SUMS.json');prior_candidate_capture_members=manifest(B,'SHA256SUMS.json');prior_candidate_validation_members=manifest(B/'validation','SHA256SUMS.json')
previous=load(B/'result.json');previous_validation=load(B/'validation/validation.json');oldparents=set(previous['matched_parent_numbers'])
check('independently validated candidate baseline',previous_validation['status']=='PASS_CANDIDATE_METADATA_VALIDATION' and previous_validation['checks']==2309 and previous_validation['errors']==[] and previous_validation['eligibility_granted'] is False and previous['candidate']==CID and prior_candidate_members==371 and prior_candidate_capture_members==362)
check('prior matched set exact retained',oldparents=={x['number'] for x in load(B/'capture/matched-parent-contexts.json')} and sorted(oldparents)==prep['prior_matched_parent_numbers']==r['prior_matched_parent_numbers'] and prep['since']==previous['delta_since']<previous['observed_from'])
check('prior intervals exact',prep['prior_candidate_capture_interval']=={k:previous[k] for k in ['observed_from','observed_through']} and prep['neutral_capture_interval']=={k:prior[k] for k in ['observed_from','observed_through']})
check('same query and pattern definitions',prep['patterns']==load(B/'prepared.json')['patterns'] and prep['queries']==load(B/'prepared.json')['queries'])
check('root manifest counts exact',root_review['prior_manifest_members_rehashed']=={'neutral-after2899':neutral_members,'1421/eligibility':prior_candidate_members})

OWN={1013:'90418d901992f65a01e52b2dd46b29d2c6fca267',1014:'3c92bf54e5844603ab6b9011c3289edb1f0a7270',1015:'79a23208dbb988190431c732d9293c29c9761f45'}
for path,spec in prep['helper_definition_hashes'].items():
 src=(W/path).read_text();lines=src.splitlines(keepends=True);nodes={x.name:x for x in ast.parse(src).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
 check('helper complete source hash '+path,sha(src.encode())==spec['source_sha256'] and set(spec['definition_sha256'])==set(prep['helper_sources'][path]))
 for name,digest in spec['definition_sha256'].items():check('helper exact source line hash '+path+':'+name,sha(''.join(lines[nodes[name].lineno-1:nodes[name].end_lineno]).encode())==digest)
check('offline lead index hash',sha((B/'offline-lead-index.json').read_bytes())==prep['offline_lead_index_sha256'])
checkpoint=load(P/'checkpoint-at-preparation.json');check('checkpoint exact immutable evidence',prep['checkpoint_evidence']=='checkpoint-at-preparation.json' and sha((P/'checkpoint-at-preparation.json').read_bytes())==prep['checkpoint_sha256']==prep['dependency_pins']['1421/final-public-guard/checkpoint-at-preparation.json'])
check('checkpoint exact projected fields',prep['checkpoint_projection']=={k:checkpoint[k] for k in prep['checkpoint_projection']})
exclusions=checkpoint['latest_exclusions'];excluded=(N/'excluded-ids.txt').read_text().splitlines()
check('current 970 exclusion projection exact',exclusions['path']==str(N/'excluded-ids.txt') and exclusions['sha256']==sha((N/'excluded-ids.txt').read_bytes()) and len(excluded)==len(set(excluded))==exclusions['count']==970 and CID not in excluded)
check('all 11 held IDs retained',len(checkpoint['local_holds'])==len(set(checkpoint['local_holds']))==11 and set(checkpoint['local_holds'])<=set(excluded) and CID not in checkpoint['local_holds'])
check('checkpoint publication identities exact',{x['candidate']:x['head_sha'] for x in [checkpoint['last_publication'],checkpoint['previous_publication']]}=={'00000007302':'3c92bf54e5844603ab6b9011c3289edb1f0a7270','00000002899':'79a23208dbb988190431c732d9293c29c9761f45'})
old_ast=ast.parse((B/'capture.py').read_text());new_ast=ast.parse((P/'capture.py').read_text());old_functions={x.name:ast.dump(x,include_attributes=False) for x in old_ast.body if isinstance(x,(ast.ClassDef,ast.FunctionDef))};new_functions={x.name:ast.dump(x,include_attributes=False) for x in new_ast.body if isinstance(x,(ast.ClassDef,ast.FunctionDef))}
check('reviewed capture function definitions unchanged',old_functions==new_functions)
check('fresh corpus root identity pin',load(W/'selection-after2899/root-corpus-review.json')['status']=='PASS_EXACT_ORIGINAL_CORPUS_FOR_FRESH_SELECTION' and load(W/'selection-after2899/root-corpus-review.json')['files_rehashed']==10000 and load(W/'selection-after2899/root-corpus-review.json')['corpus_manifest_sha256']==sha((W/'clean-conjecture-corpus-manifest.json').read_bytes()))

records=[json.loads(x) for x in (C/'request-provenance.jsonl').read_text().splitlines()];parsed={};headers={}
check('request count and limits',len(records)==r['actual_requests']==51 and len(records)<=r['request_cap']==prep['request_cap'] and r['elapsed_seconds']<=r['seconds_cap']==prep['seconds_cap'])
check('sequential request IDs',[x['stdout_file'] for x in records]==['raw/request-%04d.stdout'%i for i in range(1,len(records)+1)])
for x in records:
 for stream in ['stdout','stderr']:
  b=(C/x[stream+'_file']).read_bytes();check('raw '+x[stream+'_file'],sha(b)==x[stream+'_sha256'] and len(b)==x[stream+'_bytes'])
 cmd=x['command'];check('command digest '+x['stdout_file'],sha(canonical(cmd))==x['command_sha256']);check('read-only API command '+x['stdout_file'],cmd[:5]==['gh','api','--include','-H','Cache-Control: no-cache'])
 endpoint=cmd[-1]
 if endpoint=='graphql':
  check('read-only GraphQL method '+x['stdout_file'],len(cmd)==10 and cmd[5:8]==['--method','POST','-f'] and cmd[8].startswith('query=query{'))
  q=cmd[8][6:];check('no proof or mutation fields '+x['stdout_file'],not re.search(r'\b(mutation|diffHunk|patch|text|object)\b',q))
 else:
  check('GET only '+x['stdout_file'],len(cmd)==6)
  if endpoint.startswith('search/issues?'):check('search repository scope '+x['stdout_file'],urllib.parse.parse_qs(urllib.parse.urlparse(endpoint).query)['q'][0].startswith('repo:'+R+' '))
  else:
   suffix=endpoint.removeprefix('repos/'+R+'/');check('metadata REST allowlist '+x['stdout_file'],endpoint.startswith('repos/'+R+'/') and bool(re.fullmatch(r'git/ref/heads/main|git/commits/[a-f0-9]{40}|git/trees/[a-f0-9]{40}|contents/(README\.md|README\.zh-CN\.md|metadata\.csv|conjectures/'+CID+r'\.md)\?ref=[a-f0-9]{40}|commits\?sha=[a-f0-9]{40}&path=solutions/'+CID+r'&per_page=100(?:&page=\d+)?|issues(?:/comments)?\?.*|pulls\?.*|commits/[a-f0-9]{40}/(?:check-runs|status)\?.*',suffix)))
 h,sep,b=(C/x['stdout_file']).read_text().replace('\r\n','\n').partition('\n\n');check('HTTP success '+x['stdout_file'],x['exit_code']==0 and sep and h.splitlines()[0].split()[1]=='200');z=json.loads(b);check('no GraphQL errors '+x['stdout_file'],not isinstance(z,dict) or not z.get('errors'));parsed[x['stdout_file']]=z;headers[x['stdout_file']]={a.lower().strip():v.strip() for line in h.splitlines()[1:] if ':' in line for a,v in [line.split(':',1)]};check('observation interval '+x['stdout_file'],r['observed_from']<=x['started_at']<=x['completed_at']<=r['observed_through'])
for f in C.glob('*.receipt.json'):
 receipt=load(f);x=receipt['request'];check('receipt source '+f.name,x in records and receipt['endpoint']==x['command'][-1]);check('receipt status '+f.name,receipt['http_status']==200 and receipt['parse_error'] is None and not receipt['graphql_errors']);check('receipt headers '+f.name,receipt['headers']==headers[x['stdout_file']]);check('receipt parsed output '+f.name,load(C/f.name.removesuffix('.receipt.json'))==parsed[x['stdout_file']])
check('one attempt for each of 51 requests',len(list(C.glob('*.attempt-0.receipt.json')))==len(records) and len(list(C.glob('*.receipt.json')))==2*len(records) and not list(C.glob('*.attempt-1*')))
check('no errors/retry resolutions',load(C/'errors.json')==load(C/'retry-resolutions.json')==[])
check('exact observed bounds',r['observed_from']==min(x['started_at'] for x in records) and r['observed_through']==max(x['completed_at'] for x in records))
# Reassemble each REST collection including empty same-path history.
page_index=load(C/'pagination-index.json')
for p in C.glob('*.pagination.json'):
 index=load(p);name=index['name'];pages=sorted(x for x in C.iterdir() if re.fullmatch(re.escape(name)+r'\.page-\d+\.json',x.name));rows=[];idkey='sha' if name=='same-path-history.json' else 'id'
 check('REST page index '+name,len(pages)==len(index['pages']) and index in page_index and index['complete'])
 for i,p in enumerate(pages):
  z=load(p);receipt=load(C/(p.name+'.receipt.json'));links=re.findall(r'<([^>]+)>;\s*rel="next"',receipt['headers'].get('link',''));check('REST page count/link '+p.name,index['pages'][i]=={'count':len(z),'next':links[0] if links else None});rows+=z
  if i:check('REST cursor chain '+p.name,index['pages'][i-1]['next']=='https://api.github.com/'+receipt['endpoint'])
 check('REST complete concatenation '+name,rows==load(C/name) and len(rows)==len({x[idkey] for x in rows})==index['count'] and index['pages'][-1]['next'] is None)
prefix=next(x for x in page_index if x['name']=='updated-pulls-since-cutoff.json');allpulls=[]
for i,p in enumerate(prefix['pages']):
 fn='updated-pulls-page-%02d.json'%i;rows=load(C/fn);rc=load(C/(fn+'.receipt.json'));links=re.findall(r'<([^>]+)>;\s*rel="next"',rc['headers'].get('link',''));allpulls+=rows
 check('updated pull page '+fn,p=={'count':len(rows),'cutoff_crossed':any(x['updated_at']<prep['since'] for x in rows),'last_updated_at':rows[-1]['updated_at'] if rows else None,'next':links[0] if links else None})
 if i:check('updated pull chain '+fn,prefix['pages'][i-1]['next']=='https://api.github.com/'+rc['endpoint'])
recent=[x for x in allpulls if x['updated_at']>=prep['since']];check('complete updated prefix',all(allpulls[i]['updated_at']>=allpulls[i+1]['updated_at'] for i in range(len(allpulls)-1)) and recent==load(C/'updated-pulls-since-cutoff.json') and len(recent)==len({x['number'] for x in recent})==prefix['count'] and prefix['complete_since']==prep['since'] and (prefix['pages'][-1]['cutoff_crossed'] or prefix['pages'][-1]['next'] is None))
check('pagination index exact names',{x['name'] for x in page_index}=={'same-path-history.json','delta-issues.json','delta-comments.json','updated-pulls-since-cutoff.json'}|{'own-'+str(n)+'-'+kind for n in OWN for kind in ['checks','status']})
# Stable source tree, exact original bytes and operative rules; no original text is displayed.
main=load(C/'main-start.json')['object']['sha'];commit=load(C/'main-commit.json');tree=load(C/'root-tree.json');by={x['path']:x for x in tree['tree']};sol=load(C/'solution-directory-tree.json');binding=load(C/'current-candidate-binding.json')
check('stable main',main==r['main_sha']==load(C/'main-final.json')['object']['sha']==binding['main_sha'])
check('root and solution identity',commit['sha']==main and commit['tree']['sha']==tree['sha']==binding['root_tree_sha'] and not tree['truncated'] and sol['sha']==by['solutions']['sha']==binding['solution_tree_sha'] and not sol['truncated'])
check('corpus unchanged',by['conjectures']['sha']==r['conjectures_tree_sha']==binding['conjectures_tree_sha']==snap['identity']['conjectures_tree_sha'])
raw,b=blob('current-original.json');source_hash=sha(b)
check('exact current original hashes',source_hash==binding['original_sha256']==r['original_sha256']==prep['source_sha256']==sha((P/'ORIGINAL.md').read_bytes())==sha((W/'1421/clean-author-input/conjecture.md').read_bytes())==load(W/'clean-conjecture-corpus-manifest.json')['files'][CID+'.md'] and raw['sha']==binding['original_git_blob_sha'])
check('original exact commit request',load(C/'current-original.json.receipt.json')['endpoint']=='repos/'+R+'/contents/conjectures/'+CID+'.md?ref='+main and raw['path']=='conjectures/'+CID+'.md')
metadata_raw,b=blob('metadata.json');metadata=list(csv.DictReader(io.StringIO(b.decode())));check('exact metadata IDs',len(metadata)==10000 and {x['id'] for x in metadata}=={str(i).zfill(11) for i in range(1,10001)})
row=next(x for x in metadata if x['id']==CID);check('explicit unsolved metadata',row==binding['candidate_metadata'] and row['proven']==row['disproven']=='false' and r['metadata_unsolved'] is True)
check('metadata root/hash',metadata_raw['sha']==by['metadata.csv']['sha']==binding['metadata_blob_sha'] and sha(b)==binding['metadata_sha256'])
check('candidate absent from exclusions and current paths',CID not in (N/'excluded-ids.txt').read_text().splitlines() and [x for x in sol['tree'] if x['path']==CID]==binding['candidate_path_entries']==[] and r['solution_path_absent'] is True)
history=load(C/'same-path-history.json');check('complete empty same path history',history==[] and binding['same_path_history_count']==r['same_path_history_count']==0 and load(C/'same-path-history.json.page-00.json.receipt.json')['endpoint']=='repos/'+R+'/commits?sha='+main+'&path=solutions/'+CID+'&per_page=100')
rules=[]
for lang,path,heading in [('en','README.md','Rules'),('zh','README.zh-CN.md','比赛规则')]:
 z,b=blob('rules-'+lang+'.json');match=re.search(r'^## '+re.escape(heading)+r'\s*\n[\s\S]*?(?=^## |\Z)',b.decode(),re.M);check('operative rules located '+path,match is not None);section=(match.group().rstrip('\n')+'\n').encode();old=next(x for x in snap['identity']['rules'] if x['path']==path)
 check('root and operative rules '+path,z['sha']==by[path]['sha'] and sha(section)==old['operative_sha256'] and section==(P/('RULES.'+lang+'.md')).read_bytes());rules.append({'path':path,'blob_sha':z['sha'],'whole_sha256':sha(b),'operative_sha256':sha(section)})
check('rule summary exact',rules==binding['rules'] and r['operative_rules_unchanged'] is True)
# Independently reconstruct neutral and delta pattern scans without rendering the underlying text.
patterns=prep['patterns'];leads={}
def scan(kind,n,identifier,fields):
 matches={field:[k for k,pattern in patterns.items() if re.search(pattern,value,re.I)] for field,value in fields.items() if isinstance(value,str)};matches={k:v for k,v in matches.items() if v}
 if matches:leads[kind+':'+str(identifier)]={'kind':kind,'parent_number':n,'record_id':identifier,'matches':matches,'metadata_context':fields}
for x in snap['issues']:scan('neutral_parent',x['number'],x['number'],{'title':x['title'],'body':x.get('body') or ''})
for kind,key,urlkey in [('neutral_comment','comments','issue_url'),('neutral_inline','inline','pull_request_url')]:
 for x in snap[key]:scan(kind,parent(x,urlkey),x['id'],{'body':x.get('body') or ''})
for pr in snap['reviews']:
 for x in pr['reviews']['nodes']:scan('neutral_review',pr['number'],x['id'],{'body':x.get('body') or ''})
for pr in load(N/'capture/complete-selected-pr-filename-scopes.json'):
 for path in pr['paths']:scan('neutral_filename',pr['number'],str(pr['number'])+':'+path,{'path':path})
delta=load(C/'delta-issues.json');comments=load(C/'delta-comments.json')
for x in delta:scan('delta_parent',x['number'],x['number'],{'title':x['title'],'body':x.get('body') or ''})
for x in recent:scan('updated_pull',x['number'],x['number'],{'title':x['title'],'body':x.get('body') or ''})
for x in comments:scan('delta_comment',parent(x,'issue_url'),x['id'],{'body':x.get('body') or ''})
baseline_match_parents=sorted({x['parent_number'] for x in leads.values()});searches=[]
check('all 21 queries executed',len(prep['queries'])==21 and {p.name for p in C.iterdir() if re.fullmatch(r'search-\d+\.json',p.name)}=={'search-'+str(i)+'.json' for i in range(21)})
for i,term in enumerate(prep['queries']):
 query='repo:'+R+' '+term;fn='search-'+str(i)+'.json';z=load(C/fn);rc=load(C/(fn+'.receipt.json'));check('exact search request '+str(i),rc['endpoint']=='search/issues?q='+urllib.parse.quote(query,safe='')+'&per_page=100')
 check('search complete unique '+str(i),z['incomplete_results'] is False and z['total_count']==len(z['items'])==len({x['id'] for x in z['items']})<=100 and not re.findall(r'<([^>]+)>;\s*rel="next"',rc['headers'].get('link','')));searches.append({'query':query,'count':len(z['items'])})
 for x in z['items']:leads['search:'+str(i)+':'+str(x['number'])]={'kind':'search','parent_number':x['number'],'record_id':str(i)+':'+str(x['number']),'matches':{'query':[query]},'metadata_context':{'title':x['title'],'body':x.get('body') or ''}}
check('search summaries exact',searches==load(C/'search-summary.json') and [x['count'] for x in searches[:3]]==r['exact_search_counts'] and [x['count'] for x in searches[3:]]==r['topic_search_counts'])
initial_match_parents=sorted({x['parent_number'] for x in leads.values()});openparents=sorted(x['number'] for x in snap['prs'] if x['state']=='OPEN');nums=sorted(set(openparents)|{x['number'] for x in delta}|{x['number'] for x in recent}|{parent(x,'issue_url') for x in comments}|set(initial_match_parents)|set(OWN)|oldparents);selection=load(C/'parent-selection.json')
check('exact parent selection',selection['numbers']==nums and selection['neutral_open_prs']==openparents and selection['metadata_match_parents']==initial_match_parents and selection['own_prs']=={str(k):v for k,v in OWN.items()} and selection['prior_matched_parent_numbers']==sorted(oldparents) and len(nums)<=40)
# Every selected parent has complete current comments, reviews, inline threads and files.
parents=load(C/'complete-current-parent-metadata.json');pmap={x['number']:x for x in parents};rawparents=load(C/'current-parent-metadata.json')['data']['repository'];freshinline=[];needed=[z['number'] for z in parents if z['__typename']=='PullRequest']
check('exact current parent coverage',len(pmap)==len(parents)==len(nums) and set(pmap)==set(nums) and set(rawparents)=={'p'+str(n) for n in nums})
for z in parents:
 n=z['number'];raw=rawparents['p'+str(n)];check('raw current parent exact '+str(n),raw==z)
 for field in ['comments','reviews','reviewThreads']:
  if field not in z:continue
  con=z[field];check('complete initial feedback connection '+str(n)+' '+field,not con['pageInfo']['hasNextPage'] and len(con['nodes'])==len({x['id'] for x in con['nodes']})==con['totalCount'])
 if z['__typename']=='PullRequest':
  con=z['reviewThreads'];check('no current inline threads '+str(n),con['totalCount']==0)
  expected={'number':n,'head_sha':z['headRefOid'],'base_sha':z['baseRefOid'],'thread_count':0,'threads':[],'pages':[{'count':0,'totalCount':0,'pageInfo':con['pageInfo']}],'complete':True};check('current inline inventory exact '+str(n),expected==load(C/('parent-'+str(n)+'-inline-inventory.json')))
 scan('current_parent',n,n,{'title':z['title'],'body':z.get('body') or ''})
 for x in z['comments']['nodes']:scan('current_comment',n,x['id'],{'body':x.get('body') or ''})
 for x in z.get('reviews',{}).get('nodes',[]):scan('current_review',n,x['id'],{'body':x.get('body') or ''})
check('fresh inline exact',load(C/'fresh-relevant-inline-metadata.json')==freshinline==[])
rawfiles=load(C/'current-parent-filenames.json')['data']['repository'];provenance=load(C/'filename-provenance.json');fmap={x['number']:x for x in provenance['records']}
check('filename parent coverage',set(rawfiles)=={'p'+str(n) for n in needed} and set(fmap)==set(needed) and provenance['fetched_numbers']==needed and len(fmap)==len(provenance['records']))
for n in needed:
 z=rawfiles['p'+str(n)];pr=pmap[n];f=fmap[n];con=z['files'];nodes=list(con['nodes']);previous=con;tails=sorted(p for p in C.iterdir() if re.fullmatch('pr-'+str(n)+r'-files-tail-\d+\.json',p.name))
 check('file initial identity '+str(n),all(z[k]==pr[k] for k in ['number','headRefOid','baseRefOid','changedFiles']))
 for index,p in enumerate(tails):
  tail=load(p)['data']['repository']['pullRequest'];cc=tail['files'];cmd=load(C/(p.name+'.receipt.json'))['request']['command'];check('file cursor and identity '+p.name,previous['pageInfo']['hasNextPage'] and previous['pageInfo']['endCursor'] and any('after:'+json.dumps(previous['pageInfo']['endCursor']) in a for a in cmd) and all(tail[k]==pr[k] for k in ['headRefOid','baseRefOid']) and cc['totalCount']==con['totalCount']);nodes+=cc['nodes'];previous=cc
 paths=[x['path'] for x in nodes];check('full complete filenames '+str(n),not previous['pageInfo']['hasNextPage'] and len(paths)==len(set(paths))==con['totalCount']==pr['changedFiles'] and f=={'number':n,'head_sha':pr['headRefOid'],'base_sha':pr['baseRefOid'],'paths':paths})
 for path in paths:scan('current_filename',n,str(n)+':'+path,{'path':path})
check('all metadata matches exactly rederived',list(leads.values())==load(C/'metadata-matches.json'))
matched=sorted({x['parent_number'] for x in leads.values()}|oldparents);missing=sorted(set(matched)-set(nums));contexts=[{'number':z['number'],'parent_metadata':z,'inline_comments':[],'filename_projection':fmap.get(z['number'])} for z in parents if z['number'] in matched]
check('matched context exact',contexts==load(C/'matched-parent-contexts.json') and missing==[] and {'matched_parent_numbers':matched,'captured_parent_numbers':[x['number'] for x in contexts],'missing_parent_numbers':missing,'complete':not missing}==load(C/'matched-context-completeness.json'))
check('retained and fresh inline exact',load(C/'retained-and-fresh-inline-metadata.json')==[x for x in snap['inline'] if parent(x,'pull_request_url') not in needed]+freshinline)
catalog={x['number']:x for x in snap['issues']};catalog.update({x['number']:x for x in delta});prnums={n for n,x in catalog.items() if 'pull_request' in x};counts=load(C/'current-parent-universe-counts.json')['data']['repository']
check('current universe counts and selected types',counts['pullRequests']['totalCount']==len(prnums) and counts['issues']['totalCount']==len(catalog)-len(prnums) and all(z['number'] in catalog and (z['__typename']=='PullRequest')==(z['number'] in prnums) for z in parents))
inherit=load(C/'inherited-inventories.json');check('inheritance exact bindings',inherit['neutral_path']==str(N) and inherit['neutral_observed_from']==prior['observed_from'] and inherit['neutral_observed_through']==prior['observed_through'] and inherit['neutral_inventory_pr_count']==prior['catalog_counts']['prs']==1009 and inherit['neutral_inline_sha256']==sha((N/'capture/complete-inline-inventory.json').read_bytes()) and inherit['neutral_review_sha256']==sha((N/'capture/complete-review-inventory.json').read_bytes()) and inherit['fresh_parent_numbers']==nums and inherit['fresh_pr_numbers']==needed and inherit['current_catalog_pr_count']==len(prnums) and inherit['global_inventories_freshly_recaptured'] is False)
for name in ['complete-inline-inventory.json','complete-review-inventory.json']:
 inv=load(N/'capture'/name);check('inherited complete universe '+name,inv['complete'] and inv['total_prs']==len(inv['prs'])==len({x['number'] for x in inv['prs']})==1009 and {x['number'] for x in inv['prs']}=={x['number'] for x in snap['prs']})
guards=load(C/'final-parent-guard.json')['data']['repository'];check('final guard coverage',set(guards)=={'p'+str(n) for n in nums})
for z in guards.values():
 old=pmap[z['number']];check('final identity feedback counts '+str(z['number']),all(z[k]==old[k] for k in z if k not in ['comments','reviews','reviewThreads']) and all(z[k]['totalCount']==old[k]['totalCount'] for k in ['comments','reviews','reviewThreads'] if k in z))
own=pmap[1015];check('latest own exact head disposition',own['headRefOid']=='79a23208dbb988190431c732d9293c29c9761f45' and load(C/'latest-own-pr-disposition.json')=={k:own[k] for k in ['number','state','updatedAt','mergedAt','mergedBy','mergeCommit','headRefOid','baseRefOid']})
check('result transformations',r['delta_counts']=={'issues':len(delta),'comments':len(comments),'independently_updated_prs':len(recent)} and r['matched_parent_numbers']==matched and r['fresh_parent_numbers']==nums and r['current_catalog_pr_count']==len(prnums) and r['inherited_inventory_pr_count']==1009 and r['global_inventories_freshly_recaptured'] is False and r['fresh_relevant_inline_count']==len(freshinline))
check('baseline leads independently reconstructed',baseline_match_parents==prep['prior_offline_lead_parent_numbers']==load(B/'offline-lead-index.json')['lead_parent_numbers'])
check('search expansion includes both new parents',sorted(set(initial_match_parents)-set(baseline_match_parents))==[595,915,933] and matched==[125,229,375,456,460,532,565,568,595,728,844,915,933,949,1004] and nums==sorted(set(matched)|set(OWN)))
check('all eighteen parent feedback collections complete',len(parents)==18 and sum(z['comments']['totalCount'] for z in parents)==2 and sum(z['reviews']['totalCount'] for z in parents)==0 and sum(z['reviewThreads']['totalCount'] for z in parents)==0)
check('prior own PR exact head',pmap[1013]['headRefOid']=='90418d901992f65a01e52b2dd46b29d2c6fca267')
context_index=[{'number':z['number'],'context_sha256':sha(canonical(z)),'comments':z['parent_metadata']['comments']['totalCount'],'reviews':z['parent_metadata']['reviews']['totalCount'],'inline_comments':len(z['inline_comments']),'filename_count':len(z['filename_projection']['paths']),'classification':'PENDING_ROOT'} for z in contexts]
save('root-context-index.json',context_index)

# Fresh own checks/statuses are validated independently and bound to heads and final guard order.
own_summaries=[]
for n,head in OWN.items():
 f=load(C/('own-pr'+str(n)+'-feedback.json'));z=pmap[n]
 check('own feedback metadata exact '+str(n),all(f[k]==z[k] for k in ['number','title','state','updatedAt','closedAt','mergedAt','mergedBy','mergeCommit','headRefOid','baseRefOid']) and f['headRefOid']==head)
 check('own feedback comments reviews inline exact '+str(n),f['comments']==z['comments']['nodes'] and f['reviews']==z['reviews']['nodes'] and f['inline_comments']==[x for x in freshinline if parent(x,'pull_request_url')==n])
 for kind,endpoint,field,stored in [('checks','check-runs','check_runs','complete_check_pages'),('status','status','statuses','complete_status_pages')]:
  pages=sorted(p for p in C.iterdir() if re.fullmatch('own-'+str(n)+'-'+kind+r'-page-\d+\.json',p.name));rows=[];total=None;page_rows=[];previous=None
  check('own status at least one page '+str(n)+' '+kind,bool(pages))
  for i,p in enumerate(pages,1):
   raw=load(p);receipt=load(C/(p.name+'.receipt.json'));links=re.findall(r'<([^>]+)>;\s*rel="next"',receipt['headers'].get('link',''));total=raw['total_count'] if total is None else total
   check('own status exact head and count '+p.name,raw['total_count']==total and receipt['endpoint']=='repos/'+R+'/commits/'+head+'/'+endpoint+'?per_page=100&page='+str(i))
   if i>1:check('own status cursor chain '+p.name,previous=='https://api.github.com/'+receipt['endpoint'])
   previous=links[0] if links else None;page_rows.append({'count':len(raw[field]),'next':previous});rows+=raw[field]
   check('own status before final disposition guard '+p.name,receipt['request']['completed_at']<=load(C/'final-parent-guard.json.receipt.json')['request']['started_at'])
  check('own status complete unique aggregate '+str(n)+' '+kind,previous is None and rows==f[field] and len(rows)==len({x['id'] for x in rows})==total and page_rows==f[stored] and {'name':'own-'+str(n)+'-'+kind,'pages':page_rows,'count':len(rows),'complete':True} in page_index)
 own_summaries.append({k:f[k] for k in ['number','state','updatedAt','mergedAt','mergedBy','mergeCommit','headRefOid','baseRefOid']}|{'comments':len(f['comments']),'reviews':len(f['reviews']),'inline':len(f['inline_comments']),'checks':len(f['check_runs']),'statuses':len(f['statuses'])})
check('own summary transformations exact',own_summaries==r['own_prs'])

pending=load(P/'pending-validation-handoff.json');check('pending handoff result exact',pending['result']==r and pending['capture_manifest_members']==capture_members==362 and pending['eligibility_granted'] is False)
for name,h in pending['files_sha256'].items():check('pending handoff digest '+name,sha((P/name).read_bytes())==h)
file_tails=sorted(p.name for p in C.iterdir() if re.fullmatch(r'pr-\d+-files-tail-\d+\.json',p.name));check('exact seven filename continuation pages',file_tails==['pr-728-files-tail-0.json','pr-728-files-tail-1.json','pr-728-files-tail-2.json','pr-915-files-tail-0.json','pr-915-files-tail-1.json','pr-949-files-tail-0.json','pr-949-files-tail-1.json'] and r['actual_requests']==prep['expected_requests_without_additional_pages']+len(file_tails))
check('large complete filename counts',{n:len(fmap[n]['paths']) for n in [728,915,949]}=={728:317,915:205,949:264})

# Compare recorded projection with direct reads of allowed metadata/hash-only source bytes.
comparison=load(P/'baseline-comparison.json');comparison_rows=[]
check('comparison directories and pins',comparison['baseline']==str(B) and comparison['current']==str(P) and comparison['baseline_handoff_sha256']==sha((B/'handoff.json').read_bytes()) and comparison['baseline_handoff_manifest_sha256']==sha((B/'handoff-SHA256SUMS.json').read_bytes()))
check('comparison exact unique selected count',len(comparison['rows'])==len({x['path'] for x in comparison['rows']})==comparison['compared']==56)
for row in comparison['rows']:
 path=row['path'];oldhash=sha((B/path).read_bytes());newhash=sha((P/path).read_bytes());expected={'path':path,'baseline_sha256':oldhash,'current_sha256':newhash,'byte_identical':oldhash==newhash}
 check('comparison selected artifact '+path,row==expected);comparison_rows.append(expected)
check('comparison all 56 identity summary',sum(x['byte_identical'] for x in comparison_rows)==comparison['byte_identical']==56 and pending['comparison']['artifacts_compared']==pending['comparison']['byte_identical']==56)
# Every raw semantic response is independently compared; only field paths, never source text, are reported.
old_records=[json.loads(x) for x in (B/'capture/request-provenance.jsonl').read_text().splitlines()]
old_by_command={};semantic=[]
for x in old_records:old_by_command.setdefault(x['command_sha256'],[]).append(x)
def differing_paths(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):return [path+'/'+str(k) for k in a.keys()^b.keys()]+[p for k in a.keys()&b.keys() for p in differing_paths(a[k],b[k],path+'/'+str(k))]
 if isinstance(a,list):return ([path+'/length'] if len(a)!=len(b) else [])+[p for i in range(min(len(a),len(b))) for p in differing_paths(a[i],b[i],path+'/'+str(i))]
 return [] if a==b else [path]
check('matching exact command sequence',len(old_records)==len(records) and [x['command_sha256'] for x in old_records]==[x['command_sha256'] for x in records])
for x in records:
 oldqueue=old_by_command.get(x['command_sha256'],[]);check('prior matching exact command '+x['stdout_file'],bool(oldqueue));old=oldqueue.pop(0)
 raw=(B/'capture'/old['stdout_file']).read_bytes();check('prior raw digest '+x['stdout_file'],sha(raw)==old['stdout_sha256'])
 z=json.loads(raw.decode().replace('\r\n','\n').partition('\n\n')[2]);paths=sorted(differing_paths(z,parsed[x['stdout_file']]))
 semantic.append({'current_raw_file':x['stdout_file'],'prior_raw_file':old['stdout_file'],'command_sha256':x['command_sha256'],'semantic_identical':not paths,'changed_field_paths':paths})
comparison_result={'selected_artifact_count':56,'selected_byte_identical':56,'raw_response_comparisons':len(semantic),'raw_semantic_identical':sum(x['semantic_identical'] for x in semantic),'raw_changed':[{k:v for k,v in x.items() if k!='command_sha256'} for x in semantic if not x['semantic_identical']]}
save('baseline-comparison-validation.json',{'summary':comparison_result,'selected_artifacts':comparison_rows,'raw_responses':semantic})
# Exact requested REST parameters and sequential timing close the aggregate/request link.
check('delta issue cutoff endpoint',load(C/'delta-issues.json.page-00.json.receipt.json')['endpoint']=='repos/'+R+'/issues?state=all&since='+prep['since']+'&sort=updated&direction=asc&per_page=100')
check('delta comments cutoff endpoint',load(C/'delta-comments.json.page-00.json.receipt.json')['endpoint']=='repos/'+R+'/issues/comments?since='+prep['since']+'&sort=updated&direction=asc&per_page=100')
check('updated pulls independent sorted endpoint',load(C/'updated-pulls-page-00.json.receipt.json')['endpoint']=='repos/'+R+'/pulls?state=all&sort=updated&direction=desc&per_page=100')
check('all requests sequential',all(records[i]['completed_at']<=records[i+1]['started_at'] for i in range(len(records)-1)))
check('preflight predates first request',root_review['time_utc']<r['observed_from'])
check('main guards enclose capture',records[0]==load(C/'main-start.json.receipt.json')['request'] and records[-1]==load(C/'main-final.json.receipt.json')['request'])
check('wall time bounded',(datetime.datetime.fromisoformat(r['observed_through'])-datetime.datetime.fromisoformat(r['observed_from'])).total_seconds()<=r['elapsed_seconds']<=180)
check('all own remain observed OPEN with zero feedback',all(x['state']=='OPEN' and x['baseRefOid']==main and all(x[k]==0 for k in ['comments','reviews','inline','checks','statuses']) for x in own_summaries))
check('immutable manifest files unchanged',all(sha((P/name).read_bytes())==h for name,h in initial_manifests.items()));manifest(P,'SHA256SUMS.json')
report={'status':'PASS_FINAL_PUBLIC_GUARD_METADATA_VALIDATION','candidate':CID,'checks':len(checks),'errors':[],'dependency_pins':len(prep['dependency_pins']),'own_prs':own_summaries,'filename_continuation_pages':len(file_tails),'actual_requests':len(records),'automatic_retries':0,'observed_from':r['observed_from'],'observed_through':r['observed_through'],'main_sha':main,'main_stability_passed':True,'capture_manifest_members':capture_members,'neutral_handoff_manifest_members':neutral_members,'prior_candidate_handoff_manifest_members':prior_candidate_members,'prior_candidate_capture_manifest_members':prior_candidate_capture_members,'comparison':comparison_result,'capture_manifest_sha256':initial_manifests['SHA256SUMS.json'],'source_sha256':source_hash,'original_git_blob_sha':binding['original_git_blob_sha'],'conjectures_tree_sha':binding['conjectures_tree_sha'],'operative_rules_unchanged':True,'metadata_unsolved':True,'current_solution_path_absent':True,'same_path_history_count':len(history),'exact_search_counts':r['exact_search_counts'],'topic_search_counts':r['topic_search_counts'],'metadata_match_records':len(leads),'baseline_match_parent_numbers':baseline_match_parents,'new_search_parent_numbers':sorted(set(initial_match_parents)-set(baseline_match_parents)),'matched_parent_numbers':matched,'fresh_parent_numbers':nums,'fresh_filename_counts':{str(n):len(fmap[n]['paths']) for n in needed},'matched_contexts_complete':True,'matched_context_packet_sha256':sha((C/'matched-parent-contexts.json').read_bytes()),'checkpoint_sha256':prep['checkpoint_sha256'],'missing_context_parent_numbers':missing,'inherited_global_inventory_pr_count':1009,'global_inventories_freshly_recaptured':False,'neutral_observed_from':prior['observed_from'],'neutral_observed_through':prior['observed_through'],'fresh_relevant_inline_count':0,'delta_counts':r['delta_counts'],'latest_own_pr':{'number':1015,'state':own['state'],'head_sha':own['headRefOid'],'base_sha':own['baseRefOid']},'eligibility_granted':False,'publication_approved':False,'root_classification_pending':True,'ready_for_root_handoff':True,'limitations':['Non-atomic public observations. Both global 1009-PR review/inline inventories are inherited from the independently validated neutral interval, not recaptured globally. Fresh complete contexts cover matched/changed/open parents with overlapping issue/comment and updated-pull checks.','Search completeness means returned bounded GitHub result counts for all 21 approved queries; it does not assert universal semantic recall.','Fifteen complete matched parent contexts require root classification. No mathematical relevance or eligibility decision was made.','Original bytes were processed only for hashes; no proof, solution, report or diff file contents were inspected.','No unpublished work, every-fork, deleted-history or full-DAG completeness claim. Later public changes require a new check.']}
save('validation-checks.json',checks);save('validation.json',report);save('SHA256SUMS.json',{str(p.relative_to(V)):sha(p.read_bytes()) for p in sorted(V.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'});print(json.dumps(report,ensure_ascii=False,indent=2))
