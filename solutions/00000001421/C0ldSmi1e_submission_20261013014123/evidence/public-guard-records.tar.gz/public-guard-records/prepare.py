import ast,difflib,hashlib,json,pathlib
P=pathlib.Path(__file__).parent;W=P.parents[1];B=W/'1421/eligibility';N=W/'neutral-after2899';original=(B/'capture.py').read_text();s=original
assert not (P/'capture').exists(),'Preserve capture'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text())
def replace(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a))
 s=s.replace(a,b)
assert sha(B/'capture.py')=='4dd75168000c7835b36f0ac6bf5ed4464ff44a5249269bc95359decd35a0447d'
assert sha(B/'prepared.json')=='147b0629e1affb448925c46fd71b6836adbc6cce120fc1bfa6e8ba5794a398c8'
assert sha(W/'1421/root-eligibility-review.json')=='2bcb590652cfda46fc3c0c76b78f44aeef50c0c37c8c7aaf2b9ca6f552056b32'
replace("N=W/'neutral-after2899';F=","N=W/'neutral-after2899';B=W/'1421/eligibility';F=")
replace("for f,h in load(N/'handoff-SHA256SUMS.json').items():require('validated neutral manifest '+f,sha((N/f).read_bytes())==h)","for base in [N,B]:\n  for f,h in load(base/'handoff-SHA256SUMS.json').items():require('validated prior manifest '+str(base)+'/'+f,sha((base/f).read_bytes())==h)\n previous=load(B/'result.json');previous_validation=load(B/'validation/validation.json');require('complete independently validated candidate baseline',previous['status']=='CANDIDATE_METADATA_CAPTURE_COMPLETE_ROOT_CLASSIFICATION_PENDING' and previous['candidate']==C and previous_validation['status']=='PASS_CANDIDATE_METADATA_VALIDATION' and not previous_validation['errors']);require('full inherited overlap retained',SINCE==previous['delta_since'] and SINCE<previous['observed_from']);oldparents=set(previous['matched_parent_numbers']);require('prior matched context inventory exact',oldparents=={x['number'] for x in load(B/'capture/matched-parent-contexts.json')})")
replace("|set(OWN));require('bounded relevant parent count'","|set(OWN)|oldparents);require('bounded relevant parent count'")
replace("'own_prs':OWN,'rule':'All baseline open PRs, new/changed parents, feedback parents, exact/topic matches, and all three current own PRs.'","'own_prs':OWN,'prior_matched_parent_numbers':sorted(oldparents),'rule':'All prior matched contexts, baseline open PRs, new/changed parents, feedback parents, current exact/topic matches, and all three current own PRs.'")
replace("matched=sorted({x['parent_number'] for x in leads.values()});","matched=sorted({x['parent_number'] for x in leads.values()}|oldparents);")
replace('fresh_relevant_inline_count=len(freshinline),own_prs=own_feedback','fresh_relevant_inline_count=len(freshinline),prior_matched_parent_numbers=sorted(oldparents),own_prs=own_feedback')
replace('complete fresh matched/changed/open-parent feedback and filenames','complete fresh prior-matched/current-matched/changed/open-parent feedback and filenames')
replace('Global inline/review inventories are explicitly inherited from neutral observation interval, not freshly recaptured.','Global inline/review inventories are explicitly inherited from neutral observation interval, not freshly recaptured. Prior root eligibility applies only to earlier local work; this capture makes no new relevance or publication decision.')
(P/'capture.py').write_text(s);ast.parse(s)
(P/'adaptation.diff').write_text('\n'.join(difflib.unified_diff(original.splitlines(),s.splitlines(),fromfile='reviewed1421/eligibility/capture.py',tofile='prepared1421/final-public-guard/capture.py',n=2))+'\n')
prepared=load(B/'prepared.json');deps=dict(prepared['dependency_pins']);deps.pop('1421/eligibility/checkpoint-at-preparation.json')
for f in ['capture.py','prepared.json','result.json','SHA256SUMS.json','handoff.json','handoff-SHA256SUMS.json','validation/validation.json','validation/SHA256SUMS.json','capture/matched-parent-contexts.json','root-context-classification.json']:
 deps['1421/eligibility/'+f]=sha(B/f)
deps['1421/root-eligibility-review.json']=sha(W/'1421/root-eligibility-review.json')
cp_bytes=(W/'checkpoint.json').read_bytes();(P/'checkpoint-at-preparation.json').write_bytes(cp_bytes);cp=json.loads(cp_bytes);deps['1421/final-public-guard/checkpoint-at-preparation.json']=sha(P/'checkpoint-at-preparation.json')
assert cp['latest_exclusions']['path']==str(N/'excluded-ids.txt') and cp['latest_exclusions']['sha256']==sha(N/'excluded-ids.txt') and cp['latest_exclusions']['count']==970
for f,h in deps.items():assert sha(W/f)==h,f
manifest_counts={}
for base in [N,B]:
 m=load(base/'handoff-SHA256SUMS.json');manifest_counts[str(base.relative_to(W))]=len(m)
 for f,h in m.items():assert sha(base/f)==h,(base,f)
prepared.update(status='PREPARED_FINAL_GUARD_NOT_RUN_PENDING_ROOT_FULL_SCRIPT_REVIEW',dependency_pins=deps,script_sha256=sha(P/'capture.py'),script_lines=len(s.splitlines()),syntax_validated=True,expected_requests_if_prior_pagination_unchanged=51,prior_candidate_capture_interval={k:load(B/'result.json')[k] for k in ['observed_from','observed_through']},prior_matched_parent_numbers=load(B/'result.json')['matched_parent_numbers'],prior_candidate_handoff_sha256=sha(B/'handoff.json'),prior_candidate_handoff_manifest_sha256=sha(B/'handoff-SHA256SUMS.json'),prior_manifests_rehashed=manifest_counts,checkpoint_projection={k:cp[k] for k in ['local_holds','last_publication','previous_publication','latest_exclusions','updated_at']},checkpoint_sha256=sha(P/'checkpoint-at-preparation.json'),adaptations='Reviewed1421candidate collector unchanged except prior candidate evidence/manifest guards, forced prior15matched contexts, explicit prior-context output and final-public-gate scope. Same21original-vocabulary queries/patterns, same00:36:00full-overlap cutoff, same12imported helpers and same own1013–1015 feedback/check/status block. No new network endpoints or pagination logic.',coverage='Fresh exact bilingual original, operative rules, solved-state metadata, solution directory/path history,21exact/topic searches, overlapping issue/comment and independent updated-pull prefixes; current full catalog count guard. Fresh complete prior15matched/currentmatched/changed/open parent metadata, comments, reviews, inline comments and filenames with head/base/count guards, all three own PR dispositions/checks/statuses before final parent guards, and stable main. Complete global1009PRreview/inline inventories remain explicitly inherited from neutral00:36:28–00:37:01 interval. Non-atomic observations and bounded query recall; no all-fork/full-DAG/deleted-history claim or automatic relevance/eligibility/publication grant. No proof/solution/report/diff contents or external/Git writes.')
# The old offline lead index remains evidence inside the sealed candidate baseline.
prepared['offline_lead_index_path']='1421/eligibility/offline-lead-index.json'
(P/'prepared.json').write_text(json.dumps(prepared,ensure_ascii=False,indent=2)+'\n')
receipt={'status':'OFFLINE_PREPARATION_COMPLETE_NO_NETWORK','capture_script_sha256':sha(P/'capture.py'),'prepared_sha256':sha(P/'prepared.json'),'capture_script_lines':len(s.splitlines()),'dependency_pins':len(deps),'prior_manifests_rehashed':manifest_counts,'queries':len(prepared['queries']),'request_cap':80,'seconds_cap':180,'automatic_retries':0,'expected_requests_without_additional_pages':44,'expected_requests_if_prior_pagination_unchanged':51,'helper_sources':prepared['helper_definition_hashes'],'no_network':not (P/'capture').exists()}
(P/'guard-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='helper_sources'},indent=2))
