import hashlib,json,pathlib,re,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
project=root/'lean'; expected=root.parent/'expected-pins'; mathlib=root/'deps'/'mathlib'
report={'toolchain_and_lock':{},'packages':[],'local_modules':{},'failures':[]}
for name in ['lean-toolchain','lake-manifest.json']:
    actual=(project/name).read_bytes(); wanted=(expected/name).read_bytes()
    report['toolchain_and_lock'][name]={'equal_expected_bytes':actual==wanted,'sha256':hashlib.sha256(actual).hexdigest()}
    if actual!=wanted: report['failures'].append('Pin mismatch: '+name)
manifest=json.loads((expected/'lake-manifest.json').read_text())
for pkg in manifest['packages']:
    path=mathlib if pkg['name']=='mathlib' else mathlib/'.lake'/'packages'/pkg['name']
    cmd=['git','-C',str(path),'rev-parse','HEAD']
    rev=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    diffcmd=['git','-C',str(path),'diff','--exit-code','HEAD','--']
    diff=subprocess.run(diffcmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    row={'name':pkg['name'],'path':str(path),'revision_command':cmd,'revision_exit':rev.returncode,'revision':rev.stdout.strip(),'expected_revision':pkg['rev'],'diff_command':diffcmd,'diff_exit':diff.returncode,'diff_output':diff.stdout}
    report['packages'].append(row)
    if rev.returncode or row['revision']!=pkg['rev'] or diff.returncode: report['failures'].append('Dependency mismatch: '+pkg['name'])
for path in sorted(project.rglob('*.lean')):
    rel=path.relative_to(project)
    if '.lake' in rel.parts or rel.name=='lakefile.lean': continue
    name='.'.join(rel.with_suffix('').parts)
    text=path.read_text()
    imports=re.findall(r'^import\s+(\S+)',text,re.M)
    report['local_modules'][name]={'path':str(rel),'imports':imports,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    prohibited=re.findall(r'\b(?:sorry|admit|axiom|native_decide|unsafe|implemented_by|extern)\b|set_option\s+(?:debug|kernel|warningAsError)',text)
    if prohibited: report['failures'].append('Prohibited source token in '+name+': '+repr(prohibited))
seen=set()
def visit(name):
    if name in seen or name not in report['local_modules']: return
    seen.add(name)
    for imp in report['local_modules'][name]['imports']: visit(imp)
visit('Conjecture2899')
report['reachable_authored_modules']=sorted(seen)
report['unreachable_authored_modules']=sorted(set(report['local_modules'])-seen)
if report['unreachable_authored_modules']: report['failures'].append('Unbuilt auxiliary modules')
report['result']='PASS' if not report['failures'] else 'FAIL'
(root/'logs'/'dependency-source-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'result':report['result'],'packages':len(report['packages']),'authored_modules':len(seen),'failures':report['failures']},indent=2))
sys.exit(bool(report['failures']))
