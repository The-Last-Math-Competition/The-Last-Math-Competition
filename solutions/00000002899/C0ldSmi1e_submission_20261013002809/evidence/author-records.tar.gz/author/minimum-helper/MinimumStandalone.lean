import Mathlib.FieldTheory.Finite.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Real.Basic
import Mathlib.Data.Nat.Find

namespace Conjecture2899

abbrev Ambient (F : Type*) (d : ℕ) := Fin d → F

def IsKakeya {F : Type*} [Field F] {d : ℕ}
    (K : Finset (Ambient F d)) : Prop :=
  ∀ v : Ambient F d, v ≠ 0 → ∃ a : Ambient F d,
    ∀ t : F, (fun i => a i + t * v i) ∈ K

theorem kakeya_card_exists (F : Type*) [Field F] [Fintype F] (d : ℕ) :
    ∃ n : ℕ, ∃ K : Finset (Ambient F d), IsKakeya K ∧ K.card = n := by
  classical
  refine ⟨(Finset.univ : Finset (Ambient F d)).card, Finset.univ, ?_, rfl⟩
  intro v hv
  exact ⟨0, fun t => Finset.mem_univ _⟩

noncomputable def minimumKakeyaSize (F : Type*) [Field F] [Fintype F]
    (d : ℕ) : ℕ := by
  classical
  exact Nat.find (kakeya_card_exists F d)

theorem minimum_attained (F : Type*) [Field F] [Fintype F] (d : ℕ) :
    ∃ K : Finset (Ambient F d), IsKakeya K ∧ K.card = minimumKakeyaSize F d := by
  classical
  exact Nat.find_spec (kakeya_card_exists F d)

theorem minimum_le_card {F : Type*} [Field F] [Fintype F] {d : ℕ}
    (K : Finset (Ambient F d)) (hK : IsKakeya K) :
    minimumKakeyaSize F d ≤ K.card := by
  classical
  exact Nat.find_min' (kakeya_card_exists F d) ⟨K, hK, rfl⟩

def ProposedEventualLowerBound (d : ℕ) : Prop :=
  ∃ c : ℝ, ∃ Q : ℕ, ∀ (F : Type) [Field F] [Fintype F],
    Q ≤ Fintype.card F →
      (Fintype.card F : ℝ)^d * (1 - c / (Fintype.card F : ℝ)) ≤
        (minimumKakeyaSize F d : ℝ)

end Conjecture2899

#print axioms Conjecture2899.kakeya_card_exists
#print axioms Conjecture2899.minimum_attained
#print axioms Conjecture2899.minimum_le_card
#print Conjecture2899.ProposedEventualLowerBound
