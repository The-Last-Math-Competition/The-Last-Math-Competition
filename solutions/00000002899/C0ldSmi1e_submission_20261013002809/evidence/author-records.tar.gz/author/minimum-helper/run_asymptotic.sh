#!/bin/zsh
set -u
TASK_AUTHOR=/Users/daniel/.codex/visualizations/2026/10/04/01a10508-f155-7f33-b06c-d34f02168fbf/competition-work/2899/author
TASK_MATHLIB="$TASK_AUTHOR/deps/mathlib"
export LEAN_PATH="$TASK_AUTHOR/lean/.lake/build/lib/lean:$TASK_MATHLIB/.lake/build/lib/lean:$TASK_MATHLIB/.lake/packages/batteries/.lake/build/lib/lean:$TASK_MATHLIB/.lake/packages/Qq/.lake/build/lib/lean:$TASK_MATHLIB/.lake/packages/aesop/.lake/build/lib/lean:$TASK_MATHLIB/.lake/packages/proofwidgets/.lake/build/lib/lean:$TASK_MATHLIB/.lake/packages/LeanSearchClient/.lake/build/lib/lean:$TASK_MATHLIB/.lake/packages/importGraph/.lake/build/lib/lean:$TASK_MATHLIB/.lake/packages/plausible/.lake/build/lib/lean"
TASK_LOG="$1"
TASK_LEAN=/Users/daniel/.codex/visualizations/2026/10/04/01a10508-f155-7f33-b06c-d34f02168fbf/competition-work/runtime/lean-4.19.0-darwin_aarch64/bin/lean
"$TASK_LEAN" -DwarningAsError=true Asymptotic.lean > "$TASK_LOG" 2>&1
TASK_EXIT=$?
print -r -- "$TASK_EXIT" > "$TASK_LOG.exit"
cat "$TASK_LOG"
exit "$TASK_EXIT"
