import os, pathlib, subprocess, sys, json
root=pathlib.Path(__file__).resolve().parent
logs=root/'logs'; logs.mkdir(exist_ok=True)
label=sys.argv[1]; args=sys.argv[2:]
project=root/'lean'
if args[:1] == ['--project']:
    project=root/args[1]; args=args[2:]
env=os.environ.copy()
env['PATH']=str(root.parents[1]/'runtime'/'lean-4.19.0-darwin_aarch64'/'bin')+os.pathsep+env.get('PATH','')
mathlib=root/'deps'/'mathlib'
paths=[project/'.lake'/'build'/'lib'/'lean', mathlib/'.lake'/'build'/'lib'/'lean']
paths += sorted((mathlib/'.lake'/'packages').glob('*/.lake/build/lib/lean'))
env['LEAN_PATH']=os.pathsep.join(map(str,paths))
r=subprocess.run(args,cwd=project,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(logs/(label+'.log')).write_text(r.stdout)
(logs/(label+'.json')).write_text(json.dumps({'argv':args,'cwd':str(project),'PATH':env['PATH'],'LEAN_PATH':env['LEAN_PATH'],'exit_code':r.returncode},indent=2)+'\n')
print(r.stdout,end=''); print('RECORDED_EXIT='+str(r.returncode));sys.exit(r.returncode)
