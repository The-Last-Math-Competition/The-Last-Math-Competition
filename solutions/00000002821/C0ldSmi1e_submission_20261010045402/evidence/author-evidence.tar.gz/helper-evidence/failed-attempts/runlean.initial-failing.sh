#!/bin/zsh
set -e
stock=/private/tmp/tlmc-standard-library-419/mathlib
export LEAN_PATH=/private/tmp/tlmc2821-limit-helper:$stock/.lake/build/lib/lean
for dep in $stock/.lake/packages/*/.lake/build/lib/lean; do
  export LEAN_PATH=$LEAN_PATH:$dep
done
exec /private/tmp/tlmc310-runtime/lean-4.19.0-darwin_aarch64/bin/lean "$@"
