#!/usr/bin/env python3
"""Compile authored Lean against read-only pinned stock, privately building missing modules."""
import hashlib, json, os, pathlib, re, subprocess, sys, time
stock = pathlib.Path('/private/tmp/tlmc-standard-library-419/mathlib')
proof = pathlib.Path('/private/tmp/tlmc2821-proof')
author = pathlib.Path('/private/tmp/tlmc2821-author')
overlay = author / 'stock-olean'
lean = '/private/tmp/tlmc310-runtime/lean-4.19.0-darwin_aarch64/bin/lean'
roots = [stock] + sorted((stock / '.lake/packages').iterdir())
builds = [r / '.lake/build/lib/lean' for r in roots]
overlay.mkdir(exist_ok=True)
# Lean resolves a module root from its first directory. Mirror stock build files
# with read-only source targets so a private missing module can share that root.
for base in builds:
    if not base.exists(): continue
    for directory, _, files in os.walk(base):
        target_dir = overlay / pathlib.Path(directory).relative_to(base)
        target_dir.mkdir(parents=True, exist_ok=True)
        for filename in files:
            target = target_dir / filename
            if not target.exists(): target.symlink_to(pathlib.Path(directory) / filename)
env = dict(os.environ, LEAN_PATH=':'.join(map(str, [proof, overlay] + builds)))
record = author / 'stock-compiled.jsonl'
done = set()
def deps(path):
    return re.findall(r'^import\s+(\S+)', path.read_text(), re.M)
def ensure(mod):
    if mod in done or mod.startswith(('Lean.', 'Init.', 'Lake.')) or mod in ('Lean', 'Init', 'Lake'):
        return
    rel = pathlib.Path(*mod.split('.'))
    if any((b / rel).with_suffix('.olean').exists() for b in [overlay] + builds):
        done.add(mod); return
    found = [(r, (r / rel).with_suffix('.lean')) for r in roots if (r / rel).with_suffix('.lean').exists()]
    if not found: raise RuntimeError('Missing stock source ' + mod)
    root, source = found[0]
    for dep in deps(source): ensure(dep)
    out = (overlay / rel).with_suffix('.olean'); out.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run([lean, '--root=' + str(root), '-o', str(out), str(source)], env=env, capture_output=True, text=True)
    stamp = str(time.time_ns())
    log = author / 'logs' / ('stock-' + mod + '-' + stamp + '.log')
    log.write_text(result.stdout + result.stderr)
    with record.open('a') as f: f.write(json.dumps(dict(module=mod, source=str(source), sha256=hashlib.sha256(source.read_bytes()).hexdigest(), output=str(out), log=str(log), returncode=result.returncode)) + '\n')
    print('stock', mod, result.returncode, flush=True)
    if result.returncode:
        print(log.read_text()); raise SystemExit(result.returncode)
    done.add(mod)
args = sys.argv[1:]
warning = '--warnings-as-errors' in args
args = [arg for arg in args if arg != '--warnings-as-errors']
for arg in args:
    source = proof / arg
    for dep in deps(source):
        if not dep.startswith('Conjecture2821.'): ensure(dep)
    out = source.with_suffix('.olean')
    cmd = [lean, '--root=' + str(proof)]
    if warning: cmd += ['-DwarningAsError=true']
    cmd += ['-o', str(out), str(source)]
    result = subprocess.run(cmd, env=env, capture_output=True, text=True)
    log = author / 'logs' / (source.stem + '-' + str(time.time_ns()) + '.log')
    log.write_text('COMMAND ' + repr(cmd) + '\n' + result.stdout + result.stderr + '\nEXIT ' + str(result.returncode) + '\n')
    print(str(log) + '\n' + result.stdout + result.stderr, flush=True)
    if result.returncode: raise SystemExit(result.returncode)
