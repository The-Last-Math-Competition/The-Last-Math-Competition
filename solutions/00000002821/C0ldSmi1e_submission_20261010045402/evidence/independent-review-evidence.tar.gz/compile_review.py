from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

review = Path('/private/tmp/tlmc2821-independent-review')
stock = Path('/private/tmp/tlmc-standard-library-419/mathlib')
proof = Path('/private/tmp/tlmc2821-proof')
lean = Path('/private/tmp/tlmc310-runtime/lean-4.19.0-darwin_aarch64/bin/lean')
env = os.environ.copy()
# Lean resolves a module-prefix directory in one search root. Mirror stock
# artifacts by symlink so the one new Mathlib object lives in that same root.
stock_lib = stock / '.lake/build/lib/lean'
overlay = review / 'stock-overlay'
for original in stock_lib.rglob('*'):
    target = overlay / original.relative_to(stock_lib)
    if original.is_dir():
        target.mkdir(parents=True, exist_ok=True)
    elif not target.exists():
        target.symlink_to(original)
paths = [review / 'compiled', overlay]
paths.extend(sorted((stock / '.lake/packages').glob('*/.lake/build/lib/lean')))
env['LEAN_PATH'] = ':'.join(str(p) for p in paths)
jobs = [(stock, 'Mathlib/Analysis/SpecialFunctions/Log/ENNRealLog.lean', review / 'stock-overlay')]
jobs += [(proof, name, review / 'compiled') for name in [
    'Conjecture2821/Basic.lean', 'Conjecture2821/Limits.lean',
    'Conjecture2821/LDP.lean', 'Conjecture2821.lean']]
record_file = review / 'compilation.json'
records = json.loads(record_file.read_text())['jobs'] if record_file.exists() else []
for source_root, relative, output_root in jobs:
    source = source_root / relative
    output = output_root / Path(relative).with_suffix('.olean')
    output.parent.mkdir(parents=True, exist_ok=True)
    command = [str(lean), '-DwarningAsError=true', '--root=' + str(source_root),
               '-o', str(output), str(source)]
    start = time.time()
    result = subprocess.run(command, cwd=review, env=env, capture_output=True, text=True)
    log = review / 'logs' / (relative.replace('/', '_') + '-' + str(time.time_ns()) + '.log')
    log.write_text(result.stdout + result.stderr)
    record = {'source': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'command': command, 'exit_code': result.returncode,
              'elapsed_seconds': round(time.time() - start, 3), 'log': str(log)}
    records.append(record)
    (review / 'compilation.json').write_text(json.dumps({'lean_path': env['LEAN_PATH'], 'jobs': records}, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        print(result.stdout + result.stderr, flush=True)
        raise SystemExit(result.returncode)
