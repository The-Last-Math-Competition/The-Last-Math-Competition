from pathlib import Path
import hashlib
import json

root = Path('/private/tmp/tlmc2821-independent-review')
clean = Path('/private/tmp/tlmc2821-clean-author-input')
proof = Path('/private/tmp/tlmc2821-proof')
paths = list(sorted(clean.glob('*')))
paths += [proof / 'Conjecture2821.lean']
paths += sorted((proof / 'Conjecture2821').glob('*.lean'))
paths += [proof / 'report.tex']
paths += [Path('/Users/daniel/.codex/worktrees/competition-formal/The-Last-Math-Competition/solutions/00000002821/C0ldSmi1e_submission_20261010045402/report.tex')]
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
source_hashes = {str(p): digest(p) for p in paths if p.is_file()}
(root / 'source_hashes.json').write_text(json.dumps(source_hashes, indent=2) + '\n')
review_files = [root / name for name in ['REVIEW.txt', 'compile_review.py', 'hash_review.py',
                                         'compilation.json', 'source_hashes.json']]
review_files += sorted((root / 'logs').glob('*.log'))
(root / 'SHA256SUMS.json').write_text(json.dumps({str(p.relative_to(root)): digest(p) for p in review_files}, indent=2) + '\n')
print(json.dumps({'review_sha256': digest(root / 'REVIEW.txt'),
                  'final_report_sha256': source_hashes[str(proof / 'report.tex')],
                  'review_manifest_sha256': digest(root / 'SHA256SUMS.json')}, indent=2))
