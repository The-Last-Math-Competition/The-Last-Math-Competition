import Lean
namespace FreshFixture
def unchanged (n : Nat) : Nat := n
theorem unchanged_ok (n : Nat) : unchanged n = n := rfl
end FreshFixture
