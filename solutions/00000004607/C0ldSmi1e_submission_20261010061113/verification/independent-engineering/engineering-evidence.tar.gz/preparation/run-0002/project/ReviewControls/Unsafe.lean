import Lean
unsafe def runtimeOnly (n : Nat) : Nat := n
