import Lean
axiom opaqueAssumption : False
opaque intermediate : False := opaqueAssumption
theorem indirect : False := intermediate
