import Lean
theorem generatedNative : (17 : Nat) + 5 = 22 := by native_decide
