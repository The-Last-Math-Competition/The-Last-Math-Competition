import Lean
namespace UnrelatedNamespace
axiom unseen : False
end UnrelatedNamespace
theorem harmless : True := True.intro
