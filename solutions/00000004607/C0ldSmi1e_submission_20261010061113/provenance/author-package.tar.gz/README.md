# Conjecture 00000004607: disproof

A convex nonnegative real function on `[0,V]` with zero endpoint values must be identically zero there. If `V > 0`, its midpoint is therefore another zero, contradicting the original assertion that only zero volume and total volume are zeros. Symmetry and an explicit formula cannot remove this contradiction.

The report treats both language versions, explains the ordinary finite positive volume domain, and does not invent a definition of “concavity correction.” It gives the flat unit torus as a familiar geometric realization of every volume in `[0,1]`; the obstruction itself applies to every positive finite total volume.

## Files and precise formal boundary

- `Disproof.lean`: all mathematical definitions and proofs. It uses stock `ConvexOn ℝ (Set.Icc 0 V) f`.
- `AxiomAudit.lean`: `#print axioms` for all three final theorems.
- `report.tex`: matching rigorous report. PDF compilation and visual review are a separate parent task and are not claimed in the author verification records.
- `lean-toolchain`, `lakefile.lean`, `lake-manifest.json`: pinned Lean 4.19.0 and Mathlib commit `c44e0c8ee63ca166450922a373c7409c5d26b00b` with its dependency revisions.
- `verification/`: actual commands, exit codes, build and strict source-replay logs, and preserved failed attempts.
- `provenance/`: original authorized inputs, input hashes, stock-source record, development source snapshot, and author provenance.
- `MANIFEST.json`: SHA-256 hashes of the frozen authored package, excluding this manifest itself and the local `.lake` cache/build directory.

In namespace `IsoperimetricCorrection`:

1. `zero_on_volume_interval`: for real `V ≥ 0`, every convex nonnegative function on `[0,V]` with both endpoint values zero vanishes throughout the interval.
2. `no_nonnegative_convex_double_zero`: for real `V > 0`, no convex nonnegative function on `[0,V]` has zero set exactly `{0,V}`.
3. `no_shape_requirements`: for real `V > 0`, no function meets those three properties together with complementary-volume symmetry.

`ShapeRequirements` names the numerical property package explicitly asserted in the original. It does **not** define the unspecified concavity correction. Functions are represented as `ℝ → ℝ` and all relevant claims are restricted to `[0,V]`; extending an interval function outside this set imposes no extra constraint. The formalization does not define an isoperimetric profile, a geometric correction operator, or “explicit,” and does not formalize the illustrative torus geometry. The impossibility of the necessary scalar properties is fully formalized; no desired conclusion is assumed.

## Reproduction

Install the Lean toolchain specified by `lean-toolchain`. In a fresh checkout with network access, obtain the pinned dependencies and their standard cached artifacts:

```sh
lake exe cache get
```

The exact Mathlib revision is fixed in `lakefile.lean`; retain the supplied manifest to fix all dependency revisions. Lake materializes the dependency checkouts as needed. Alternatively, use already available stock dependency packages at these revisions. The author used local package symlinks to the supplied stock library and existing caches, without fetching or modifying stock sources.

Run the complete project build and then replay both source files with warnings as errors:

```sh
lake build
lake env lean -DwarningAsError=true -DautoImplicit=false Disproof.lean
lake env lean -DwarningAsError=true -DautoImplicit=false AxiomAudit.lean
```

Both libraries are default build targets. The replay of `Disproof.lean` elaborates the source again; the audit imports its built module and prints the axiom dependencies. Each theorem reports only `propext`, `Classical.choice`, and `Quot.sound`. The source uses no admitted proofs, custom axioms, or native evaluation proof mechanism.

The recorded local binary directory was `/private/tmp/tlmc310-runtime/lean-4.19.0-darwin_aarch64/bin`, with Lean reporting version 4.19.0 and commit `6caaee842e94`. These local paths are operational details, not project dependencies.

## Actual verification evidence

`verification/RESULTS.json` records successful exit codes for the final complete `lake build`, strict replay of `Disproof.lean`, and strict replay/axiom audit of `AxiomAudit.lean`. It also records the exact verified source hashes and a before/after inventory of dependency files (outside `.git`); the changed-path list is empty. The dependency artifacts were pre-existing stock caches. This is a complete build of this project, **not** a fresh build of all Mathlib.

Development attempts are retained without presenting them as successful checks:

- `build-attempt-01.log`: compilation failed because the first import list did not bring real numbers into scope. `provenance/failed-attempt-01.lean.txt` preserves that source. The small wrapper itself also failed afterward because it used a reserved zsh variable; `build-attempt-01-wrapper.txt` records this separately.
- `build-attempt-02.log` and `.json`: an optional nested operating-system sandbox could not start (`Operation not permitted`, exit 71); no Lean check occurred in this attempt. Its policy is preserved in `dependency-readonly.sb`. This is not a source failure or a successful sandbox enforcement claim.
- `build-attempt-03.log` and `.json`: after adding the stock real-number import, both project libraries built successfully and all three axiom reports passed. A dependency-file inventory recorded no changes.
- `full-build.log`, `strict-disproof.log`, and `strict-axiom-audit.log`: the final successful checks. An empty strict source log means the command completed without warnings or errors; its exit code is in `RESULTS.json`.

No auxiliary mathematical computation is needed. This package makes no claim about competition eligibility, public history, maintainer acceptance, or publication; those are handled separately.
